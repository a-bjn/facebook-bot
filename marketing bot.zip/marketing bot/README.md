# Facebook Group Poster Bot (Playwright Automation)

An automated Facebook group posting bot that uses **Playwright browser automation** to post URL links to multiple Facebook groups. This solution bypasses Facebook API restrictions by using real browser automation.

## ⚠️ Important Disclaimer

- This tool uses browser automation which may violate Facebook's Terms of Service
- Use at your own risk - your account could be banned
- Intended for personal use only, not for spam or commercial purposes
- Respect group rules and posting guidelines
- Use responsibly with appropriate delays between posts

## ✨ Features

- **Browser Automation**: Uses Playwright to control a real browser
- **Multi-Account Support**: Manage multiple Facebook accounts
- **Session Persistence**: Saves login sessions (no need to re-login)
- **Group Management**: Automatically fetch and manage your Facebook groups
- **Bulk Posting**: Post to multiple groups simultaneously
- **Human-like Behavior**: Random delays and natural interactions
- **Post History**: Track all posts with success/failure status
- **Modern Web Interface**: Clean, responsive UI
- **2FA Support**: Handles two-factor authentication

## 📋 Prerequisites

- Node.js (version 14 or higher)
- Windows/Mac/Linux
- Facebook account(s)

## 🚀 Installation

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Install Playwright browsers:**
   ```bash
   npx playwright install chromium
   ```

3. **Start the application:**
   ```bash
   npm start
   ```

4. **Open your browser:**
   Navigate to `http://localhost:3000`

## 📖 Usage

### 1. Add Facebook Account

1. Click "Add Account" button
2. Enter your Facebook email and password
3. A browser window will open
4. If you have 2FA, complete it in the browser
5. Session will be saved automatically

### 2. Sync Groups

1. Select an account from the dropdown
2. Click "Sync Groups"
3. Wait for the bot to fetch your groups (10-30 seconds)
4. Your groups will appear in the list

### 3. Post to Groups

1. Select the groups you want to post to (green checkmark)
2. Enter the URL you want to share
3. Optionally add a message
4. Click "Post to Selected Groups"
5. Watch the progress - browser will post to each group

### 4. Monitor Results

- View posting history in real-time
- Check success/failure status for each post
- See statistics in the right panel

## 🔧 How It Works

1. **Browser Control**: Playwright launches a real Chrome browser
2. **Login**: Automates the Facebook login process
3. **Session Saving**: Stores cookies so you don't need to re-login
4. **Group Fetching**: Navigates to Facebook and extracts group information
5. **Posting**: For each selected group:
   - Opens the group page
   - Clicks the post creation button
   - Fills in the message and URL
   - Clicks "Post"
   - Waits 3-6 seconds before moving to next group

## 🛡️ Security Features

- Passwords are NOT stored in the database
- Only browser session cookies are saved
- Sessions stored locally in the `sessions/` folder
- Rate limiting to prevent excessive API calls
- Human-like delays to avoid detection

## ⚙️ Configuration

The `.env` file is optional for this version. Default settings:

```env
PORT=3000
DB_PATH=./database.sqlite
JWT_SECRET=(auto-generated)
```

## 📁 Project Structure

```
facebook-group-poster-bot/
├── services/
│   └── facebook-automation.js    # Playwright automation logic
├── routes/
│   ├── auth-automation.js         # Login/authentication
│   ├── groups-automation.js       # Group management
│   └── posts-automation.js        # Posting functionality
├── sessions/                      # Saved browser sessions
├── database.sqlite                # Local database
└── public/                        # Web interface
```

## 🐛 Troubleshooting

### Browser doesn't open
- Make sure Playwright is installed: `npx playwright install chromium`
- Check if port 3000 is available

### Login fails
- Verify your email/password are correct
- Complete any 2FA challenges in the browser
- Facebook may require additional verification for new locations

### Groups not loading
- Wait longer (Facebook can be slow)
- Try refreshing the groups list
- Make sure you're logged in correctly

### Posting fails
- Facebook's interface may have changed
- Some groups restrict posting to admins
- You may have hit Facebook's rate limits

### "Session expired" error
- Click on the account and login again
- Sessions expire after some time

## 🔒 Best Practices

1. **Use Delays**: Don't post too quickly (3-6 seconds between posts)
2. **Limit Posting**: Don't post to too many groups at once (5-10 max)
3. **Vary Content**: Don't spam the same link repeatedly
4. **Respect Groups**: Only post relevant content
5. **Monitor Account**: Watch for warnings from Facebook
6. **Use Test Account**: Test with a secondary account first

## 🚨 Risks

- **Account Ban**: Facebook may detect and ban your account
- **Rate Limiting**: Posting too fast triggers blocks
- **Temporary Restrictions**: Facebook may temporarily restrict posting
- **Group Removal**: Admins may remove you from groups
- **Legal Issues**: Violating TOS may have legal consequences

## 📊 Statistics

Track your posting activity:
- Total posts made
- Success/failure rates
- Number of groups used
- Historical data

## 🔄 Updates

The bot may stop working if Facebook changes their interface. When this happens:

1. Check for updates in the repository
2. Update the selectors in `services/facebook-automation.js`
3. Test thoroughly before bulk posting

## 💡 Tips

- **Headless Mode**: Set `headless: true` in automation.init() for invisible browser
- **Debugging**: Set `headless: false` to watch the browser in action
- **Slow Mode**: Increase delays in `humanDelay()` if getting blocked
- **Multiple Accounts**: Use different accounts for different group sets

## 📝 Notes

- Sessions are stored in `sessions/session_{accountId}.json`
- Database is SQLite (`database.sqlite`)
- Logs appear in the console
- First login shows visible browser, subsequent uses headless mode

## 🤝 Contributing

This is a personal project. Use responsibly.

## 📄 License

MIT License - Use at your own risk

## 🆘 Support

If you encounter issues:
1. Check the console logs for errors
2. Try with a visible browser (`headless: false`)
3. Verify Facebook hasn't changed their layout
4. Test manually in a real browser first

---

**Remember**: This tool automates Facebook, which goes against their Terms of Service. Use it responsibly and ethically. Don't spam!