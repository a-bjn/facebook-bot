// Shared session manager for browser automation
const activeSessions = new Map();

class SessionManager {
    static setSession(accountId, automation) {
        activeSessions.set(parseInt(accountId), automation);
    }

    static getSession(accountId) {
        return activeSessions.get(parseInt(accountId));
    }

    static hasSession(accountId) {
        return activeSessions.has(parseInt(accountId));
    }

    static async closeSession(accountId) {
        const automation = activeSessions.get(parseInt(accountId));
        if (automation) {
            await automation.close();
            activeSessions.delete(parseInt(accountId));
        }
    }

    static async closeAll() {
        for (const [accountId, automation] of activeSessions) {
            await automation.close();
        }
        activeSessions.clear();
    }
}

module.exports = SessionManager;
