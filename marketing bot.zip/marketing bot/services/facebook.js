const axios = require('axios');

const FACEBOOK_GRAPH_API_BASE = 'https://graph.facebook.com/v18.0';

class FacebookService {
  constructor(accessToken) {
    this.accessToken = accessToken;
    this.api = axios.create({
      baseURL: FACEBOOK_GRAPH_API_BASE,
      params: {
        access_token: accessToken
      }
    });
  }

  // Get user profile information
  async getUserProfile() {
    try {
      const response = await this.api.get('/me', {
        params: {
          fields: 'id,name,email,picture.type(large)'
        }
      });
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  // Get user's groups
  async getUserGroups() {
    try {
      const response = await this.api.get('/me/groups', {
        params: {
          fields: 'id,name,description,privacy,member_count,administrator,can_post'
        }
      });
      return response.data.data || [];
    } catch (error) {
      throw this.handleError(error);
    }
  }

  // Get specific group information
  async getGroupInfo(groupId) {
    try {
      const response = await this.api.get(`/${groupId}`, {
        params: {
          fields: 'id,name,description,privacy,member_count'
        }
      });
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  // Check if user can post to a specific group
  async canPostToGroup(groupId) {
    try {
      const response = await this.api.get(`/${groupId}`, {
        params: {
          fields: 'can_post'
        }
      });
      return response.data.can_post || false;
    } catch (error) {
      console.error(`Error checking post permission for group ${groupId}:`, error.message);
      return false;
    }
  }

  // Post a link to a group
  async postToGroup(groupId, message, link) {
    try {
      const postData = {
        message: message,
        link: link
      };

      const response = await this.api.post(`/${groupId}/feed`, postData);
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  // Post only a link (without additional message)
  async postLinkToGroup(groupId, link, message = '') {
    try {
      const postData = {
        link: link
      };

      if (message && message.trim()) {
        postData.message = message;
      }

      const response = await this.api.post(`/${groupId}/feed`, postData);
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  // Get post information
  async getPost(postId) {
    try {
      const response = await this.api.get(`/${postId}`, {
        params: {
          fields: 'id,message,link,created_time,updated_time'
        }
      });
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  // Delete a post
  async deletePost(postId) {
    try {
      const response = await this.api.delete(`/${postId}`);
      return response.data;
    } catch (error) {
      throw this.handleError(error);
    }
  }

  // Validate access token
  async validateToken() {
    try {
      const response = await this.api.get('/me', {
        params: {
          fields: 'id'
        }
      });
      return { valid: true, userId: response.data.id };
    } catch (error) {
      return { valid: false, error: error.message };
    }
  }

  // Get long-lived access token
  static async getLongLivedToken(shortLivedToken) {
    try {
      const response = await axios.get(`${FACEBOOK_GRAPH_API_BASE}/oauth/access_token`, {
        params: {
          grant_type: 'fb_exchange_token',
          client_id: process.env.FACEBOOK_APP_ID,
          client_secret: process.env.FACEBOOK_APP_SECRET,
          fb_exchange_token: shortLivedToken
        }
      });
      return response.data;
    } catch (error) {
      throw new Error(`Failed to get long-lived token: ${error.message}`);
    }
  }

  // Handle API errors
  handleError(error) {
    if (error.response) {
      const fbError = error.response.data.error;
      const errorMessage = fbError ? fbError.message : 'Facebook API error';
      const errorCode = fbError ? fbError.code : error.response.status;
      
      return new Error(`Facebook API Error (${errorCode}): ${errorMessage}`);
    } else if (error.request) {
      return new Error('No response from Facebook API');
    } else {
      return new Error(`Request error: ${error.message}`);
    }
  }
}

module.exports = FacebookService;
