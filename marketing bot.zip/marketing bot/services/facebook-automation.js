const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs').promises;

class FacebookAutomation {
    constructor() {
        this.browser = null;
        this.context = null;
        this.page = null;
        this.sessionDir = path.join(__dirname, '..', 'sessions');
    }

    async ensureSessionDir() {
        try {
            await fs.mkdir(this.sessionDir, { recursive: true });
        } catch (error) {
            console.error('Error creating session directory:', error);
        }
    }

    async init(headless = false) {
        await this.ensureSessionDir();
        
        this.browser = await chromium.launch({
            headless: headless,
            args: [
                '--no-sandbox', 
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-blink-features=AutomationControlled'
            ],
            timeout: 60000
        });

        this.context = await this.browser.newContext({
            viewport: { width: 1280, height: 720 },
            userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            ignoreHTTPSErrors: true,
            javaScriptEnabled: true
        });

        // Set default timeout for all actions
        this.context.setDefaultTimeout(10000);
        this.context.setDefaultNavigationTimeout(10000);

        this.page = await this.context.newPage();
        
        // Prevent page from closing unexpectedly
        this.page.on('close', () => {
            console.log('⚠️ Page closed unexpectedly!');
        });
        
        this.browser.on('disconnected', () => {
            console.log('⚠️ Browser disconnected!');
        });
        
        this.context.on('close', () => {
            console.log('⚠️ Browser context closed!');
        });
        
        return this.page;
    }

    async login(email, password, accountId) {
        try {
            console.log('Navigating to Facebook...');
            await this.page.goto('https://www.facebook.com/', { waitUntil: 'domcontentloaded' });
            
            // Wait for page to load
            await this.page.waitForTimeout(5000);

            // Always proceed with login - no session checking
            console.log('Proceeding with fresh login...');

            console.log('Filling login form...');
            
            // Wait for login form to be visible
            console.log('Waiting for email field (#email)...');
            await this.page.waitForSelector('#email', { timeout: 10000 });
            console.log('✓ Email field found');
            
            // Wait a bit after cookie modal (give time to close it)
            console.log('Waiting 5 seconds for you to close cookie modal...');
            await this.page.waitForTimeout(5000);
            
            // Click email field to focus it
            console.log('Clicking email field...');
            await this.page.click('#email');
            await this.page.waitForTimeout(200); // Reduced from 500ms
            
            // Clear the field first
            console.log('Clearing email field...');
            await this.page.fill('#email', '');
            await this.page.waitForTimeout(100); // Reduced from 300ms
            
            // Type email character by character (like Selenium send_keys)
            console.log('Typing email:', email);
            await this.page.type('#email', email, { delay: 50 }); // Reduced from 100ms to 50ms per character
            console.log('✓ Email filled');
            await this.page.waitForTimeout(300); // Reduced from 1000ms

            // Click password field to focus it
            console.log('Clicking password field...');
            await this.page.click('#pass');
            await this.page.waitForTimeout(200); // Reduced from 500ms
            
            // Clear the field first
            console.log('Clearing password field...');
            await this.page.fill('#pass', '');
            await this.page.waitForTimeout(100); // Reduced from 300ms
            
            // Type password character by character
            console.log('Typing password...');
            await this.page.type('#pass', password, { delay: 50 }); // Reduced from 100ms to 50ms per character
            console.log('✓ Password filled');
            await this.page.waitForTimeout(500); // Reduced from 1500ms

            // Click login button (find by name="login")
            console.log('Clicking login button...');
            await this.page.click('button[name="login"]');
            console.log('✓ Login button clicked');
            
            // Wait for navigation/login to complete
            console.log('Waiting for login to complete...');
            await this.page.waitForTimeout(2000); // Reduced from 3s to 2s

            // Check for 2FA or security checks
            const needsVerification = await this.page.locator('text=/verify|security|checkpoint/i').count() > 0;
            
            if (needsVerification) {
                console.log('2FA verification required');
                return {
                    success: false,
                    needsVerification: true,
                    message: 'Manual verification required. Please complete the verification in the browser.'
                };
            }

            // Quick check if login was successful
            const loginSuccess = await this.page.locator('[aria-label="Account"]').count() > 0 ||
                                await this.page.url().includes('facebook.com') && 
                                !await this.page.url().includes('login');

            if (loginSuccess) {
                console.log('Login successful!');
                // No session saving - fresh login every time
                return { success: true, message: 'Login successful' };
            } else {
                return { success: false, message: 'Login failed. Please check credentials.' };
            }

        } catch (error) {
            console.error('Login error:', error);
            return { success: false, message: error.message };
        }
    }

    async loadSession(accountId) {
        try {
            const sessionFile = path.join(this.sessionDir, `session_${accountId}.json`);
            const sessionData = await fs.readFile(sessionFile, 'utf8');
            const cookies = JSON.parse(sessionData);
            
            console.log(`Loading session for account ${accountId}...`);
            await this.context.addCookies(cookies);
            
            // Navigate with more lenient settings
            await this.page.goto('https://www.facebook.com/', { 
                waitUntil: 'domcontentloaded',
                timeout: 30000 
            });
            
            // Wait a bit for dynamic content
            await this.page.waitForTimeout(3000);
            
            // Verify session is still valid - check multiple indicators
            const isLoggedIn = await this.page.evaluate(() => {
                // Check for account menu, profile icon, or other logged-in indicators
                return !!(
                    document.querySelector('[aria-label="Account"]') ||
                    document.querySelector('[aria-label*="Your profile"]') ||
                    document.querySelector('a[href*="/profile.php"]') ||
                    !document.querySelector('input[name="email"]') // No login form
                );
            });
            
            console.log(`Session ${isLoggedIn ? 'valid' : 'invalid'} for account ${accountId}`);
            return isLoggedIn;
        } catch (error) {
            console.error('Error loading session:', error);
            return false;
        }
    }

    async saveSession(accountId) {
        // Session saving disabled - fresh login every time
        console.log('Session saving disabled - no cookies saved');
    }

    async getGroups() {
        try {
            console.log('Fetching groups...');
            
            // Check if browser is still alive
            if (!this.page || !this.browser || !this.browser.isConnected()) {
                throw new Error('Browser is not connected. Please login again.');
            }
            
            // Use the "Your groups" page which shows all joined groups
            console.log('Navigating to groups page...');
            try {
                // Use 'commit' instead of 'domcontentloaded' for faster navigation
                await this.page.goto('https://www.facebook.com/groups/joins/?nav_source=tab', { 
                    waitUntil: 'commit', // Faster - just waits for navigation to be committed
                    timeout: 15000 // 15 seconds
                });
                console.log('✓ Navigation started, page loading...');
            } catch (error) {
                console.error('Error navigating to groups page:', error.message);
                // Try to continue anyway if we're already on Facebook
                const currentUrl = this.page.url();
                if (currentUrl.includes('facebook.com')) {
                    console.log('Already on Facebook, continuing...');
                } else {
                    throw new Error('Failed to navigate to groups page: ' + error.message);
                }
            }
            
            // Wait for initial content to appear
            console.log('Waiting for initial groups to load...');
            await this.page.waitForTimeout(2000); // Reduced from 3s to 2s

            // Smart scrolling with group collection
            console.log('Starting smart scroll to load all groups...');
            const allGroups = new Map();
            let noNewGroupsCount = 0;
            let scrollCount = 0;
            const maxScrolls = 100; // Much higher limit for many groups
            const maxNoChangeScrolls = 5; // Stop if no new groups after 5 scrolls (not 3)

            while (scrollCount < maxScrolls && noNewGroupsCount < maxNoChangeScrolls) {
                // Check if browser/page is still alive
                if (!this.page || this.page.isClosed() || !this.browser || !this.browser.isConnected()) {
                    console.error('❌ Browser disconnected during scrolling!');
                    throw new Error('Browser disconnected. Session may have expired.');
                }

                // Check if still logged in every 5 scrolls
                if (scrollCount > 0 && scrollCount % 5 === 0) {
                    const stillLoggedIn = await this.page.evaluate(() => {
                        const loginForm = document.querySelector('input[name="email"]');
                        return !loginForm;
                    }).catch(() => false);
                    
                    if (!stillLoggedIn) {
                        console.error('❌ Got logged out during scrolling!');
                        throw new Error('Session expired during scrolling. Please login again.');
                    }
                    console.log('✓ Session still valid');
                }

                const beforeCount = allGroups.size;

                // Extract groups currently visible
                const currentGroups = await this.page.evaluate(() => {
                    const groupsArray = [];
                    const allLinks = document.querySelectorAll('a[href*="facebook.com/groups/"]');
                    
                    allLinks.forEach(link => {
                        try {
                            const href = link.href;
                            const text = link.textContent.trim();
                            
                            // Match group ID from URL
                            const match = href.match(/facebook\.com\/groups\/([a-zA-Z0-9._-]+)/);
                            if (match && match[1] && text) {
                                const groupId = match[1];
                                
                                // Skip navigation/UI URLs
                                if (['feed', 'discover', 'joins', 'create', 'settings', 'browse', 'search'].includes(groupId)) {
                                    return;
                                }
                                
                                // Skip if text is too short or likely UI text
                                if (text.length < 5) return;
                                
                                // Skip common UI text
                                const uiText = ['English', 'Română', 'See all', 'Vezi tot', 'Groups', 'Grupuri'];
                                if (uiText.includes(text)) return;
                                
                                // Skip if in footer
                                if (link.closest('footer')) return;
                                
                                // Must have reasonable group ID length
                                if (groupId.length < 3) return;
                                
                                // Clean up group name - remove "Ultima activitate:" and similar text
                                let cleanName = text;
                                // Remove "Ultima activitate: acum X minute/ore/zile/secunde"
                                cleanName = cleanName.replace(/Ultima activitate:.*$/i, '').trim();
                                // Remove "Last activity: ..." in English
                                cleanName = cleanName.replace(/Last activity:.*$/i, '').trim();
                                // Remove any remaining extra whitespace
                                cleanName = cleanName.replace(/\s+/g, ' ').trim();
                                
                                // Skip if name became too short after cleaning
                                if (cleanName.length < 3) return;
                                
                                groupsArray.push({
                                    id: groupId,
                                    name: cleanName,
                                    url: `https://www.facebook.com/groups/${groupId}`
                                });
                            }
                        } catch (e) {
                            // Skip problematic links
                        }
                    });

                    return groupsArray;
                }).catch(err => {
                    console.log(`Error extracting groups: ${err.message}`);
                    return [];
                });

                // Add new groups to collection
                currentGroups.forEach(group => {
                    if (!allGroups.has(group.id)) {
                        allGroups.set(group.id, group);
                    }
                });

                const afterCount = allGroups.size;
                const newGroups = afterCount - beforeCount;

                console.log(`Scroll ${scrollCount + 1}: Found ${newGroups} new groups (total: ${afterCount})`);

                // Check if we found new groups
                if (newGroups === 0) {
                    noNewGroupsCount++;
                    console.log(`No new groups found (${noNewGroupsCount}/${maxNoChangeScrolls})`);
                } else {
                    noNewGroupsCount = 0; // Reset counter when we find new groups
                }

                // Scroll down smoothly (500px per scroll)
                await this.page.evaluate(() => window.scrollBy(0, 700)).catch(err => {
                    console.log(`Scroll error: ${err.message}`);
                });
                
                // Wait longer for content to load (Facebook needs time)
                await this.humanDelay(2000, 2500);
                scrollCount++;
            }

            console.log(`\n✅ Scrolling complete!`);
            
            // Convert Map to Array
            const groups = Array.from(allGroups.values());
            
            // Display actual count
            if (groups.length === 0) {
                console.log('⚠️ No groups found. You might not be a member of any groups, or the page didn\'t load properly.');
            } else {
                console.log(`📊 Total groups found: ${groups.length}`);
            }
            
            // Show breakdown
            console.log(`\n📈 Group Statistics:`);
            console.log(`   • Total unique groups: ${groups.length}`);
            console.log(`   • Scrolls performed: ${scrollCount}`);
            console.log(`   • Average groups per scroll: ${(groups.length / scrollCount).toFixed(1)}`);

            return groups;

        } catch (error) {
            console.error('Error fetching groups:', error);
            return [];
        }
    }

    async postToGroup(groupId, message, link) {
        try {
            console.log(`\n=== Posting to group: ${groupId} ===`);
            
            // Navigate to group
            console.log('Navigating to group page...');
            await this.page.goto(`https://www.facebook.com/groups/${groupId}`, { 
                waitUntil: 'domcontentloaded',
                timeout: 30000 
            });
            
            // Scroll to top to ensure elements are visible
            await this.page.evaluate(() => window.scrollTo(0, 0));
            await this.humanDelay(3000, 4000);

            // Click on "Scrie ceva..." (Write something) - using evaluate to prevent auto-scroll
            console.log('Step 1: Looking for "Scrie ceva..." button...');
            
            const clicked = await this.page.evaluate(() => {
                // Find the "Scrie ceva..." element
                const spans = Array.from(document.querySelectorAll('span'));
                const postButton = spans.find(span => span.textContent.includes('Scrie ceva'));
                
                if (postButton) {
                    postButton.click();
                    return true;
                }
                
                // Alternative: look for placeholder
                const placeholders = document.querySelectorAll('[placeholder*="Scrie"]');
                if (placeholders.length > 0) {
                    placeholders[0].click();
                    return true;
                }
                
                return false;
            });

            if (!clicked) {
                throw new Error('Could not find "Scrie ceva..." button');
            }
            
            console.log('✓ Clicked "Scrie ceva..." button');

            // Wait for the modal to appear
            console.log('Step 2: Waiting for modal "Creează o postare" to appear...');
            await this.humanDelay(2000, 3000);

            // Wait for modal and its content to be fully loaded
            try {
                // Look for the modal by its title
                await this.page.waitForSelector('div[role="dialog"]', { timeout: 10000, state: 'visible' });
                console.log('✓ Modal appeared');
            } catch (error) {
                console.log('Could not find modal by role="dialog", trying other selectors...');
            }

            await this.humanDelay(1000, 1500);

            // Find and click the text field inside the modal
            console.log('Step 3: Looking for text field inside modal...');
            
            const postContent = message ? `${message}\n\n${link}` : link;
            
            try {
                // Strategy: Find contenteditable div inside the modal/dialog
                const modalSelector = 'div[role="dialog"] div[contenteditable="true"]';
                
                console.log('Looking for contenteditable field in modal...');
                await this.page.waitForSelector(modalSelector, { timeout: 5000, state: 'visible' });
                console.log('✓ Found text field in modal');
                
                // Click to focus the field
                console.log('Clicking on text field...');
                await this.page.click(modalSelector);
                await this.humanDelay(500, 1000);
                
                // Clear any placeholder content
                console.log('Clearing placeholder...');
                await this.page.evaluate((selector) => {
                    const fields = document.querySelectorAll(selector);
                    fields.forEach(field => {
                        field.innerHTML = '';
                        field.textContent = '';
                    });
                }, modalSelector);
                await this.humanDelay(300, 500);
                
                // Type the URL
                console.log(`Step 4: Typing URL: "${postContent}"`);
                await this.page.type(modalSelector, postContent, { delay: 50 });
                console.log('✓ Finished typing URL');
                
                // Verify the content was typed
                const fieldContent = await this.page.evaluate((selector) => {
                    const field = document.querySelector(selector);
                    return field ? field.textContent : '';
                }, modalSelector);
                
                console.log(`✓ Field now contains: "${fieldContent}"`);
                
                if (!fieldContent || fieldContent.trim() === '') {
                    throw new Error('Field is still empty after typing!');
                }
                
                // Wait 2 seconds before deleting
                console.log('Waiting 2 seconds before deleting text...');
                await this.page.waitForTimeout(2000);
                
                // Delete the typed text using keyboard commands (most reliable method)
                console.log('Deleting typed text using keyboard selection...');
                
                // Click on the field to focus it
                await this.page.click(modalSelector);
                await this.page.waitForTimeout(300);
                
                // Select all text using Ctrl+A
                console.log('Selecting all text with Ctrl+A...');
                await this.page.keyboard.down('Control');
                await this.page.keyboard.press('a');
                await this.page.keyboard.up('Control');
                await this.page.waitForTimeout(300);
                
                // Delete selected text using Backspace
                console.log('Deleting selected text with Backspace...');
                await this.page.keyboard.press('Backspace');
                await this.page.waitForTimeout(300);
                
                // Try Delete key as well just in case
                await this.page.keyboard.press('Delete');
                await this.page.waitForTimeout(300);
                
                // Also remove the link preview card if it exists
                console.log('Removing link preview card...');
                await this.page.evaluate(() => {
                    const modal = document.querySelector('div[role="dialog"]');
                    if (modal) {
                        // Look for the X button on the link preview card
                        const closeButtons = modal.querySelectorAll('[aria-label*="Remove"], [aria-label*="Elimină"], div[role="button"]');
                        closeButtons.forEach(btn => {
                            // Check if this is a close button for a preview (usually has an X or close icon)
                            const hasXIcon = btn.querySelector('svg') || btn.textContent.includes('×');
                            if (hasXIcon) {
                                btn.click();
                            }
                        });
                        
                        // Alternative: directly remove preview containers
                        const previews = modal.querySelectorAll('div[style*="background"], [data-testid*="preview"]');
                        previews.forEach(preview => {
                            // Only remove if it contains a video or image
                            if (preview.querySelector('video') || preview.querySelector('img[src*="external"]')) {
                                preview.remove();
                            }
                        });
                    }
                });
                console.log('✓ Text and link preview deleted');
                
                // Verify deletion
                const deletedContent = await this.page.evaluate((selector) => {
                    const field = document.querySelector(selector);
                    return field ? field.textContent.trim() : '';
                }, modalSelector);
                console.log(`✓ Field after deletion: "${deletedContent}"`);
                
                // Wait 1 second after deleting
                console.log('Waiting 1 second after deleting...');
                await this.page.waitForTimeout(1000);
                
            } catch (error) {
                console.error('Error with modal field:', error.message);
                throw new Error(`Could not type into modal field: ${error.message}`);
            }

            // Click "Postează" button using JavaScript (prevents scrolling)
            console.log('Step 5: Looking for "Postează" button...');
            
            const posted = await this.page.evaluate(() => {
                // Find "Postează" button
                const spans = Array.from(document.querySelectorAll('span'));
                const postButton = spans.find(span => span.textContent === 'Postează');
                
                if (postButton) {
                    // Find the clickable parent button/div
                    let clickableElement = postButton;
                    while (clickableElement && clickableElement.tagName !== 'BUTTON' && !clickableElement.hasAttribute('role')) {
                        clickableElement = clickableElement.parentElement;
                    }
                    
                    if (clickableElement) {
                        clickableElement.click();
                        return true;
                    }
                }
                
                return false;
            });

            if (!posted) {
                throw new Error('Could not find "Postează" button');
            }
            
            console.log('✓ Clicked "Postează" button');

            // Wait for post to complete
            await this.humanDelay(4000, 6000);

            console.log('✅ Post successful!\n');
            return {
                success: true,
                message: 'Posted successfully'
            };

        } catch (error) {
            console.error(`❌ Error posting to group ${groupId}:`, error.message);
            return {
                success: false,
                error: error.message
            };
        }
    }

    async close() {
        if (this.browser) {
            await this.browser.close();
            this.browser = null;
            this.context = null;
            this.page = null;
        }
    }

    // Utility method to add human-like delays
    async humanDelay(min = 1000, max = 3000) {
        const delay = Math.floor(Math.random() * (max - min + 1)) + min;
        await this.page.waitForTimeout(delay);
    }
}

module.exports = FacebookAutomation;
