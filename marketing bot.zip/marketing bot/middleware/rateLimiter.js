const { RateLimiterMemory } = require('rate-limiter-flexible');

// Rate limiter for general API requests
const rateLimiter = new RateLimiterMemory({
  keyGenerator: (req) => req.ip,
  points: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100, // Number of requests
  duration: parseInt(process.env.RATE_LIMIT_WINDOW_MS) / 1000 || 900, // Per 15 minutes (900 seconds)
});

// Rate limiter for Facebook API calls (more restrictive)
const facebookApiLimiter = new RateLimiterMemory({
  keyGenerator: (req) => req.ip,
  points: 20, // 20 requests
  duration: 3600, // Per hour
});

// Rate limiter for posting (very restrictive to avoid spam)
const postingLimiter = new RateLimiterMemory({
  keyGenerator: (req) => req.ip,
  points: 5, // 5 posts
  duration: 3600, // Per hour
});

const rateLimiterMiddleware = (limiter) => {
  return async (req, res, next) => {
    try {
      await limiter.consume(req.ip);
      next();
    } catch (rejRes) {
      const secs = Math.round(rejRes.msBeforeNext / 1000) || 1;
      res.set('Retry-After', String(secs));
      res.status(429).json({
        error: 'Too Many Requests',
        message: `Rate limit exceeded. Try again in ${secs} seconds.`,
        retryAfter: secs
      });
    }
  };
};

module.exports = {
  rateLimiter: rateLimiterMiddleware(rateLimiter),
  facebookApiLimiter: rateLimiterMiddleware(facebookApiLimiter),
  postingLimiter: rateLimiterMiddleware(postingLimiter)
};
