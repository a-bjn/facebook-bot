const jwt = require('jsonwebtoken');
const { getDatabase } = require('../database/init');

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

function generateToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '24h' });
}

function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    return null;
  }
}

function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(403).json({ error: 'Invalid or expired token' });
  }

  req.user = decoded;
  next();
}

async function validateFacebookAccount(req, res, next) {
  try {
    const { accountId } = req.params;
    const db = getDatabase();

    if (!accountId) {
      return res.status(400).json({ error: 'Account ID is required' });
    }

    const account = await new Promise((resolve, reject) => {
      db.get(
        'SELECT * FROM facebook_accounts WHERE id = ?',
        [accountId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!account) {
      return res.status(404).json({ error: 'Facebook account not found' });
    }

    // Check if token is expired
    if (account.token_expires_at && Date.now() > account.token_expires_at) {
      return res.status(401).json({ 
        error: 'Facebook token expired',
        message: 'Please re-authenticate your Facebook account'
      });
    }

    req.facebookAccount = account;
    next();
  } catch (error) {
    console.error('Error validating Facebook account:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}

module.exports = {
  generateToken,
  verifyToken,
  authenticateToken,
  validateFacebookAccount
};
