// Facebook Group Poster Bot - Frontend Application
class FacebookGroupPosterApp {
    constructor() {
        this.selectedGroups = new Map(); // groupId -> {groupData, accountId}
        this.accounts = [];
        this.currentAccount = null;
        this.groups = [];
        
        this.init();
    }

    init() {
        this.bindEvents();
        this.loadAccounts();
        this.loadStats();
        this.loadHistory();
    }

    bindEvents() {
        // Account management
        document.getElementById('addAccountBtn').addEventListener('click', () => this.showAuthModal());
        document.getElementById('facebookAuthBtn').addEventListener('click', () => this.authenticateFacebook());
        document.getElementById('refreshBtn').addEventListener('click', () => this.refreshAll());

        // Account selection
        document.getElementById('accountSelect').addEventListener('change', (e) => {
            this.selectAccount(e.target.value);
        });

        // Group management
        // Sync happens automatically during login
        document.getElementById('groupSearch').addEventListener('input', (e) => {
            this.filterGroups(e.target.value);
        });
        document.getElementById('postableOnly').addEventListener('change', (e) => {
            this.filterGroups(document.getElementById('groupSearch').value, e.target.checked);
        });

        // Posting
        document.getElementById('postBtn').addEventListener('click', () => this.createPost());
        document.getElementById('clearSelectionBtn').addEventListener('click', () => this.clearSelection());
        document.getElementById('postUrl').addEventListener('input', () => this.validatePostForm());
        document.getElementById('postMessage').addEventListener('input', () => this.validatePostForm());

        // History filters
        document.getElementById('historyAccountFilter').addEventListener('change', () => this.loadHistory());
        document.getElementById('historyStatusFilter').addEventListener('change', () => this.loadHistory());

        // Modal events
        document.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.target.closest('.modal').classList.remove('show');
            });
        });

        // Close modals on backdrop click
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.classList.remove('show');
                }
            });
        });
    }

    // Utility Methods
    async apiCall(endpoint, options = {}) {
        try {
            const response = await fetch(`/api${endpoint}`, {
                headers: {
                    'Content-Type': 'application/json',
                    ...options.headers
                },
                ...options
            });

            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.message || data.error || 'API request failed');
            }

            return data;
        } catch (error) {
            console.error('API Error:', error);
            this.showToast(error.message, 'error');
            throw error;
        }
    }

    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <i class="fas ${this.getToastIcon(type)}"></i>
                <span>${message}</span>
            </div>
        `;

        document.getElementById('toastContainer').appendChild(toast);

        setTimeout(() => {
            toast.remove();
        }, 5000);
    }

    getToastIcon(type) {
        const icons = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };
        return icons[type] || icons.info;
    }

    showLoading(text = 'Loading...') {
        document.getElementById('loadingText').textContent = text;
        document.getElementById('loadingModal').classList.add('show');
    }

    hideLoading() {
        document.getElementById('loadingModal').classList.remove('show');
    }

    // Account Management
    async loadAccounts() {
        try {
            const data = await this.apiCall('/accounts');
            this.accounts = data.accounts;
            this.renderAccounts();
            this.updateAccountSelects();
        } catch (error) {
            console.error('Failed to load accounts:', error);
        }
    }

    renderAccounts() {
        const container = document.getElementById('accountsList');
        
        if (this.accounts.length === 0) {
            container.innerHTML = `
                <div class="text-center" style="grid-column: 1 / -1; padding: 40px;">
                    <i class="fab fa-facebook" style="font-size: 3rem; color: #1877f2; margin-bottom: 20px;"></i>
                    <h3>No Facebook accounts connected</h3>
                    <p class="text-muted">Connect your Facebook account to start posting to groups</p>
                    <button class="btn btn-primary mt-2" onclick="app.showAuthModal()">
                        <i class="fas fa-plus"></i> Add Facebook Account
                    </button>
                </div>
            `;
            return;
        }

        container.innerHTML = this.accounts.map(account => {
            const profilePic = account.profile_picture 
                ? `<img src="${account.profile_picture}" alt="${account.name}" style="width: 50px; height: 50px; border-radius: 50%; object-fit: cover; margin-right: 12px;">`
                : `<i class="fas fa-user-circle" style="color: #1877f2; margin-right: 12px; font-size: 50px;"></i>`;
            
            return `
            <div class="account-card ${this.currentAccount?.id === account.id ? 'selected' : ''}" 
                 onclick="app.selectAccountCard(${account.id})">
                <div class="account-header">
                    ${profilePic}
                    <div class="account-info">
                        <h3>${account.name}</h3>
                        <p>${account.email || 'No email'}</p>
                        ${account.tokenExpired ? '<p style="color: #dc3545; font-weight: 600;">⚠️ Token Expired</p>' : ''}
                    </div>
                </div>
                <div class="account-stats">
                    <div class="stat-item">
                        <div class="stat-value">${account.groupCount || 0}</div>
                        <div class="stat-label">Groups</div>
                    </div>
                </div>
                <div class="account-actions">
                    <button class="btn btn-secondary btn-small" onclick="event.stopPropagation(); app.deleteAccount(${account.id})">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
        `;
        }).join('');
    }

    updateAccountSelects() {
        const selects = ['accountSelect', 'historyAccountFilter'];
        
        selects.forEach(selectId => {
            const select = document.getElementById(selectId);
            const currentValue = select.value;
            
            select.innerHTML = `<option value="">${selectId === 'accountSelect' ? 'Select Account' : 'All Accounts'}</option>` +
                this.accounts.map(account => 
                    `<option value="${account.id}">${account.name}</option>`
                ).join('');
            
            if (currentValue) {
                select.value = currentValue;
            }
        });
    }

    selectAccountCard(accountId) {
        this.selectAccount(accountId);
        document.getElementById('accountSelect').value = accountId;
    }

    async selectAccount(accountId) {
        if (!accountId) {
            this.currentAccount = null;
            this.groups = [];
            document.getElementById('groupsSection').style.display = 'none';
            document.getElementById('postingSection').style.display = 'none';
            this.renderAccounts();
            return;
        }

        this.currentAccount = this.accounts.find(acc => acc.id == accountId);
        if (!this.currentAccount) return;

        this.renderAccounts();
        document.getElementById('groupsSection').style.display = 'block';
        
        await this.loadGroups();
    }

    showAuthModal() {
        // Show custom login form instead of OAuth
        const modal = document.getElementById('authModal');
        const modalBody = modal.querySelector('.modal-body');
        
        modalBody.innerHTML = `
            <p>Login with your Facebook credentials to enable automatic posting.</p>
            <div class="form-group">
                <label for="fbEmail">Facebook Email</label>
                <input type="email" id="fbEmail" class="form-input" placeholder="your-email@example.com" required>
            </div>
            <div class="form-group">
                <label for="fbPassword">Facebook Password</label>
                <input type="password" id="fbPassword" class="form-input" placeholder="Your password" required>
            </div>
            <div class="form-group">
                <label for="accountName">Account Name (optional)</label>
                <input type="text" id="accountName" class="form-input" placeholder="My Facebook Account">
            </div>
            <div style="background: #fff3cd; padding: 15px; border-radius: 8px; margin: 15px 0;">
                <strong>⚠️ Important:</strong>
                <ul style="margin: 10px 0 0 20px; font-size: 0.9rem;">
                    <li>Your credentials are processed locally</li>
                    <li>A browser will open for login</li>
                    <li>Your session is saved securely</li>
                    <li>May require 2FA verification</li>
                </ul>
            </div>
            <button id="fbLoginSubmit" class="btn btn-facebook">
                <i class="fab fa-facebook-f"></i> Login with Browser Automation
            </button>
        `;
        
        modal.classList.add('show');
        
        // Bind submit button
        setTimeout(() => {
            document.getElementById('fbLoginSubmit').addEventListener('click', () => this.authenticateFacebook());
        }, 100);
    }

    async authenticateFacebook() {
        try {
            const email = document.getElementById('fbEmail').value.trim();
            const password = document.getElementById('fbPassword').value;
            const accountName = document.getElementById('accountName').value.trim();

            if (!email || !password) {
                this.showToast('Please enter email and password', 'warning');
                return;
            }

            this.showLoading('Logging in... A browser window will open.');

            const response = await this.apiCall('/auth/facebook/login', {
                method: 'POST',
                body: JSON.stringify({
                    email: email,
                    password: password,
                    accountName: accountName
                })
            });

            this.hideLoading();

            if (response.needsVerification) {
                this.showToast('Please complete verification in the browser window', 'warning');
                // Wait for user to complete verification
                this.waitForVerification(response.accountId);
            } else if (response.success) {
                this.showToast('Login successful!', 'success');
                document.getElementById('authModal').classList.remove('show');
                await this.loadAccounts();
            }

        } catch (error) {
            this.hideLoading();
            console.error('Facebook auth error:', error);
        }
    }

    async waitForVerification(accountId) {
        const checkVerification = async () => {
            try {
                const response = await this.apiCall(`/auth/facebook/verify-complete/${accountId}`, {
                    method: 'POST'
                });

                if (response.success) {
                    this.showToast('Verification completed!', 'success');
                    document.getElementById('authModal').classList.remove('show');
                    await this.loadAccounts();
                    return true;
                }
            } catch (error) {
                // Continue waiting
            }
            return false;
        };

        // Check every 5 seconds for up to 5 minutes
        let attempts = 0;
        const maxAttempts = 60;

        const interval = setInterval(async () => {
            attempts++;
            const completed = await checkVerification();

            if (completed || attempts >= maxAttempts) {
                clearInterval(interval);
                if (attempts >= maxAttempts) {
                    this.showToast('Verification timeout. Please try again.', 'error');
                }
            }
        }, 5000);
    }

    async deleteAccount(accountId) {
        if (!confirm('Are you sure you want to delete this Facebook account? This will also delete all associated groups and posts.')) {
            return;
        }

        try {
            await this.apiCall(`/accounts/${accountId}`, { method: 'DELETE' });
            this.showToast('Account deleted successfully', 'success');
            await this.loadAccounts();
            
            if (this.currentAccount?.id == accountId) {
                this.selectAccount(null);
            }
        } catch (error) {
            console.error('Failed to delete account:', error);
        }
    }

    // Group Management
    async loadGroups() {
        if (!this.currentAccount) return;

        try {
            this.showLoading('Loading groups...');
            const data = await this.apiCall(`/groups/account/${this.currentAccount.id}?limit=1000`);
            this.groups = data.groups;
            console.log(`Loaded ${this.groups.length} groups from API`);
            this.renderGroups();
        } catch (error) {
            console.error('Failed to load groups:', error);
            this.groups = [];
            this.renderGroups();
        } finally {
            this.hideLoading();
        }
    }

    renderGroups() {
        const container = document.getElementById('groupsList');
        
        if (this.groups.length === 0) {
            container.innerHTML = `
                <div class="text-center" style="grid-column: 1 / -1; padding: 40px;">
                    <i class="fas fa-layer-group" style="font-size: 3rem; color: #1877f2; margin-bottom: 20px;"></i>
                    <h3>No groups found</h3>
                    <p class="text-muted">Sync your account to load Facebook groups</p>
                    <button class="btn btn-primary mt-2" onclick="app.syncGroups()">
                        <i class="fas fa-sync"></i> Sync Groups
                    </button>
                </div>
            `;
            return;
        }

        container.innerHTML = this.groups.map(group => {
            const isSelected = this.selectedGroups.has(group.group_id);
            
            return `
                <div class="group-card ${isSelected ? 'selected' : ''}" 
                     onclick="app.toggleGroupSelection('${group.group_id}')">
                    <div class="group-header">
                        <div class="group-name">${group.name}</div>
                    </div>
                </div>
            `;
        }).join('');
    }

    filterGroups(searchTerm = '', postableOnly = false) {
        const cards = document.querySelectorAll('.group-card');
        
        cards.forEach(card => {
            const groupName = card.querySelector('.group-name').textContent.toLowerCase();
            const canPost = card.classList.contains('no-post') === false;
            
            const matchesSearch = !searchTerm || groupName.includes(searchTerm.toLowerCase());
            const matchesPostable = !postableOnly || canPost;
            
            card.style.display = (matchesSearch && matchesPostable) ? 'block' : 'none';
        });
    }

    toggleGroupSelection(groupId) {
        const group = this.groups.find(g => g.group_id === groupId);
        if (!group) return;

        if (this.selectedGroups.has(groupId)) {
            this.selectedGroups.delete(groupId);
        } else {
            this.selectedGroups.set(groupId, {
                groupData: group,
                accountId: this.currentAccount.id
            });
        }

        this.renderGroups();
        this.updateSelectedGroupsList();
        this.validatePostForm();
        
        // Show posting section if groups are selected
        if (this.selectedGroups.size > 0) {
            document.getElementById('postingSection').style.display = 'block';
        }
    }

    updateSelectedGroupsList() {
        const container = document.getElementById('selectedGroupsList');
        const count = document.getElementById('selectedGroupsCount');
        
        count.textContent = this.selectedGroups.size;

        if (this.selectedGroups.size === 0) {
            container.innerHTML = '<p class="text-muted text-center">No groups selected</p>';
            return;
        }

        container.innerHTML = Array.from(this.selectedGroups.entries()).map(([groupId, data]) => `
            <div class="selected-group-item">
                <div class="selected-group-info">
                    <div class="selected-group-name">${data.groupData.name}</div>
                    <div class="selected-group-account">${this.currentAccount.name}</div>
                </div>
                <button class="remove-group-btn" onclick="app.removeGroupSelection('${groupId}')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `).join('');
    }

    removeGroupSelection(groupId) {
        this.selectedGroups.delete(groupId);
        this.renderGroups();
        this.updateSelectedGroupsList();
        this.validatePostForm();
    }

    clearSelection() {
        this.selectedGroups.clear();
        this.renderGroups();
        this.updateSelectedGroupsList();
        this.validatePostForm();
    }

    async syncGroups() {
        if (!this.currentAccount) {
            this.showToast('Please select an account first', 'warning');
            return;
        }

        try {
            this.showLoading('Syncing groups from Facebook...');
            await this.apiCall(`/groups/account/${this.currentAccount.id}/sync`, { method: 'POST' });
            this.showToast('Groups synced successfully', 'success');
            await this.loadGroups();
        } catch (error) {
            console.error('Failed to sync groups:', error);
        } finally {
            this.hideLoading();
        }
    }

    async syncAccountGroups(accountId) {
        try {
            this.showLoading('Syncing groups...');
            await this.apiCall(`/groups/account/${accountId}/sync`, { method: 'POST' });
            this.showToast('Groups synced successfully', 'success');
            
            if (this.currentAccount?.id == accountId) {
                await this.loadGroups();
            }
        } catch (error) {
            console.error('Failed to sync groups:', error);
        } finally {
            this.hideLoading();
        }
    }

    // Posting
    validatePostForm() {
        const postUrl = document.getElementById('postUrl').value.trim();
        const hasGroups = this.selectedGroups.size > 0;
        const postBtn = document.getElementById('postBtn');
        
        postBtn.disabled = !postUrl || !hasGroups;
    }

    async createPost() {
        const postUrl = document.getElementById('postUrl').value.trim();
        const message = document.getElementById('postMessage').value.trim();

        if (!postUrl) {
            this.showToast('Please enter a post URL', 'warning');
            return;
        }

        if (this.selectedGroups.size === 0) {
            this.showToast('Please select at least one group', 'warning');
            return;
        }

        try {
            this.showLoading('Posting to groups...');

            // Group selections by account
            const accountGroups = new Map();
            this.selectedGroups.forEach((data, groupId) => {
                if (!accountGroups.has(data.accountId)) {
                    accountGroups.set(data.accountId, []);
                }
                accountGroups.get(data.accountId).push(groupId);
            });

            const allResults = [];

            // Post to each account's groups
            for (const [accountId, groupIds] of accountGroups) {
                const result = await this.apiCall('/posts/bulk', {
                    method: 'POST',
                    body: JSON.stringify({
                        accountId: parseInt(accountId),
                        groupIds: groupIds,
                        postUrl: postUrl,
                        message: message
                    })
                });

                allResults.push(...result.results);
            }

            const successCount = allResults.filter(r => r.success).length;
            const failureCount = allResults.filter(r => !r.success).length;

            if (successCount > 0) {
                this.showToast(`Posted to ${successCount} groups successfully!`, 'success');
            }
            
            if (failureCount > 0) {
                this.showToast(`Failed to post to ${failureCount} groups`, 'error');
            }

            // Clear form and selection
            document.getElementById('postUrl').value = '';
            document.getElementById('postMessage').value = '';
            this.clearSelection();
            
            // Refresh history and stats
            await this.loadHistory();
            await this.loadStats();

        } catch (error) {
            console.error('Failed to create post:', error);
        } finally {
            this.hideLoading();
        }
    }

    // History
    async loadHistory() {
        try {
            const accountFilter = document.getElementById('historyAccountFilter').value;
            const statusFilter = document.getElementById('historyStatusFilter').value;
            
            const params = new URLSearchParams();
            if (accountFilter) params.append('accountId', accountFilter);
            if (statusFilter) params.append('status', statusFilter);
            params.append('limit', '20');

            const data = await this.apiCall(`/posts/history?${params}`);
            this.renderHistory(data.posts);
        } catch (error) {
            console.error('Failed to load history:', error);
            this.renderHistory([]);
        }
    }

    renderHistory(posts) {
        const container = document.getElementById('historyList');
        
        if (posts.length === 0) {
            container.innerHTML = `
                <div class="text-center" style="padding: 40px;">
                    <i class="fas fa-history" style="font-size: 3rem; color: #65676b; margin-bottom: 20px;"></i>
                    <h3>No posting history</h3>
                    <p class="text-muted">Your posting history will appear here</p>
                </div>
            `;
            return;
        }

        container.innerHTML = posts.map(post => `
            <div class="history-item status-${post.status}">
                <div class="history-content">
                    <a href="${post.post_url}" target="_blank" class="history-url">${post.post_url}</a>
                    <div class="history-meta">
                        <span><strong>${post.account_name}</strong> → ${post.group_name || 'Unknown Group'}</span>
                        <span>${new Date(post.created_at).toLocaleString()}</span>
                        ${post.error_message ? `<br><span style="color: #dc3545;">Error: ${post.error_message}</span>` : ''}
                    </div>
                </div>
                <div class="history-status status-${post.status}">${post.status}</div>
            </div>
        `).join('');
    }

    // Statistics
    async loadStats() {
        try {
            const data = await this.apiCall('/posts/stats');
            this.renderStats(data.stats);
        } catch (error) {
            console.error('Failed to load stats:', error);
            this.renderStats({});
        }
    }

    renderStats(stats) {
        const container = document.getElementById('statsContent');
        
        container.innerHTML = `
            <div class="stat-card">
                <h4>${stats.totalPosts || 0}</h4>
                <p>Total Posts</p>
            </div>
            <div class="stat-card">
                <h4>${stats.successfulPosts || 0}</h4>
                <p>Successful</p>
            </div>
            <div class="stat-card">
                <h4>${stats.failedPosts || 0}</h4>
                <p>Failed</p>
            </div>
            <div class="stat-card">
                <h4>${stats.successRate || 0}%</h4>
                <p>Success Rate</p>
            </div>
            <div class="stat-card">
                <h4>${stats.uniqueGroups || 0}</h4>
                <p>Groups Used</p>
            </div>
            <div class="stat-card">
                <h4>${stats.uniqueAccounts || 0}</h4>
                <p>Accounts</p>
            </div>
        `;
    }

    // Refresh all data
    async refreshAll() {
        this.showLoading('Refreshing data...');
        try {
            await Promise.all([
                this.loadAccounts(),
                this.loadStats(),
                this.loadHistory()
            ]);
            
            if (this.currentAccount) {
                await this.loadGroups();
            }
            
            this.showToast('Data refreshed successfully', 'success');
        } catch (error) {
            console.error('Failed to refresh data:', error);
        } finally {
            this.hideLoading();
        }
    }
}

// Initialize the app
const app = new FacebookGroupPosterApp();

// Handle Facebook OAuth callback
if (window.location.search.includes('code=')) {
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    
    if (code) {
        // Send code to backend
        fetch('/api/auth/facebook/callback', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ code })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                app.showToast('Facebook account connected successfully!', 'success');
                // Close popup if this is a popup window
                if (window.opener) {
                    window.close();
                } else {
                    // Redirect to clean URL
                    window.location.href = '/';
                }
            } else {
                app.showToast(data.message || 'Authentication failed', 'error');
            }
        })
        .catch(error => {
            console.error('Auth callback error:', error);
            app.showToast('Authentication failed', 'error');
        });
    }
}
