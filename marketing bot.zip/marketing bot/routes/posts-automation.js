const express = require('express');
const { getDatabase } = require('../database/init');
const FacebookAutomation = require('../services/facebook-automation');
const SessionManager = require('../services/session-manager');
const { postingLimiter } = require('../middleware/rateLimiter');

const router = express.Router();

// Get or create automation session for posting (VISIBLE browser)
async function getAutomationSession(accountId) {
    const db = getDatabase();
    
    // Get account email from database
    const account = await new Promise((resolve, reject) => {
        db.get('SELECT * FROM facebook_accounts WHERE id = ?', [accountId], (err, row) => {
            if (err) reject(err);
            else resolve(row);
        });
    });
    
    if (!account || !account.email) {
        throw new Error('Account not found or missing email');
    }
    
    // Always close any existing session and create a NEW visible one for posting
    if (SessionManager.hasSession(accountId)) {
        const oldAutomation = SessionManager.getSession(accountId);
        await oldAutomation.close();
        SessionManager.closeSession(accountId);
    }

    // Create NEW VISIBLE browser for posting
    console.log('Opening visible browser for posting...');
    const automation = new FacebookAutomation();
    await automation.init(false); // VISIBLE browser for posting
    
    // Set fullscreen
    await automation.page.setViewportSize({ width: 1920, height: 1080 });
    
    // Navigate to Facebook login page
    console.log('Navigating to Facebook login page...');
    await automation.page.goto('https://www.facebook.com/login', { 
        waitUntil: 'domcontentloaded',
        timeout: 15000 
    });
    
    // Wait for login page to load
    await automation.page.waitForTimeout(2000);
    
    // Wait for cookie modal and let user close it manually
    console.log('Please close the cookie modal if it appears...');
    await automation.page.waitForTimeout(3000);
    
    // Auto-fill ONLY the email field
    console.log(`Auto-filling email: ${account.email}`);
    try {
        await automation.page.waitForSelector('#email', { timeout: 10000 });
        await automation.page.click('#email');
        await automation.page.waitForTimeout(200);
        await automation.page.fill('#email', '');
        await automation.page.waitForTimeout(100);
        await automation.page.type('#email', account.email, { delay: 50 });
        console.log('✓ Email auto-filled');
    } catch (error) {
        console.error('Error auto-filling email:', error.message);
        throw new Error('Could not auto-fill email field');
    }
    
    // Keep browser open for manual password entry and login
    console.log('⏳ Please manually enter your password and click login...');
    console.log('Waiting up to 60 seconds for manual login...');
    
    // Wait for successful login (check for up to 60 seconds)
    const maxWaitTime = 60000; // 60 seconds
    const checkInterval = 2000; // Check every 2 seconds
    const startTime = Date.now();
    let loggedIn = false;
    
    while (Date.now() - startTime < maxWaitTime) {
        try {
            // Check current URL first (safer than evaluate during navigation)
            const currentUrl = automation.page.url();
            
            // If we're no longer on the login page, we're probably logged in
            if (currentUrl.includes('facebook.com') && !currentUrl.includes('login')) {
                loggedIn = true;
                console.log('✅ Manual login successful! (detected by URL change)');
                break;
            }
            
            // Try to check for logged-in elements (may fail during navigation)
            try {
                const isLoggedIn = await automation.page.evaluate(() => {
                    return !!(
                        document.querySelector('[aria-label="Account"]') ||
                        document.querySelector('[data-pagelet="LeftRail"]')
                    );
                });
                
                if (isLoggedIn) {
                    loggedIn = true;
                    console.log('✅ Manual login successful!');
                    break;
                }
            } catch (evalError) {
                // Execution context destroyed means navigation is happening (probably logged in)
                if (evalError.message.includes('Execution context was destroyed')) {
                    console.log('Navigation detected, waiting for page to stabilize...');
                    await automation.page.waitForTimeout(3000);
                    
                    // Check URL again after navigation
                    const newUrl = automation.page.url();
                    if (newUrl.includes('facebook.com') && !newUrl.includes('login')) {
                        loggedIn = true;
                        console.log('✅ Manual login successful! (confirmed after navigation)');
                        break;
                    }
                }
            }
            
        } catch (error) {
            console.log('Error checking login status:', error.message);
        }
        
        // Wait before checking again
        await automation.page.waitForTimeout(checkInterval);
    }
    
    if (!loggedIn) {
        await automation.close();
        throw new Error('Login timeout - manual login was not completed within 60 seconds');
    }
    
    // Wait a bit more for the page to fully load after login
    console.log('Waiting for page to fully load...');
    await automation.page.waitForTimeout(3000);

    // Store in session manager
    SessionManager.setSession(accountId, automation);
    console.log('✅ Browser ready for posting!');
    return automation;
}

// Post to multiple groups
router.post('/bulk', postingLimiter, async (req, res) => {
    try {
        const { accountId, groupIds, postUrl, message = '' } = req.body;

        if (!accountId || !groupIds || !Array.isArray(groupIds) || groupIds.length === 0) {
            return res.status(400).json({
                error: 'Account ID and group IDs array are required'
            });
        }

        if (!postUrl || !postUrl.trim()) {
            return res.status(400).json({
                error: 'Post URL is required'
            });
        }

        const db = getDatabase();

        // Get account
        const account = await new Promise((resolve, reject) => {
            db.get('SELECT * FROM facebook_accounts WHERE id = ?', [accountId], (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });

        if (!account) {
            return res.status(404).json({ error: 'Account not found' });
        }

        // Get groups
        const placeholders = groupIds.map(() => '?').join(',');
        const groups = await new Promise((resolve, reject) => {
            db.all(`
                SELECT group_id, name
                FROM facebook_groups
                WHERE account_id = ? AND group_id IN (${placeholders})
            `, [accountId, ...groupIds], (err, rows) => {
                if (err) reject(err);
                else resolve(rows);
            });
        });

        if (groups.length === 0) {
            return res.status(400).json({
                error: 'No valid groups found'
            });
        }

        // Get automation session
        const automation = await getAutomationSession(parseInt(accountId));

        const results = [];

        // Post to each group
        for (const group of groups) {
            try {
                // Create post record
                const postId = await new Promise((resolve, reject) => {
                    db.run(`
                        INSERT INTO posts (account_id, group_id, post_url, status, created_at)
                        VALUES (?, ?, ?, 'pending', CURRENT_TIMESTAMP)
                    `, [accountId, group.group_id, postUrl], function(err) {
                        if (err) reject(err);
                        else resolve(this.lastID);
                    });
                });

                // Attempt to post
                const postResult = await automation.postToGroup(
                    group.group_id,
                    message,
                    postUrl
                );

                if (postResult.success) {
                    // Update as successful
                    await new Promise((resolve, reject) => {
                        db.run(`
                            UPDATE posts
                            SET status = 'posted', posted_at = CURRENT_TIMESTAMP
                            WHERE id = ?
                        `, [postId], (err) => {
                            if (err) reject(err);
                            else resolve();
                        });
                    });

                    results.push({
                        groupId: group.group_id,
                        groupName: group.name,
                        success: true
                    });
                } else {
                    // Update as failed
                    await new Promise((resolve, reject) => {
                        db.run(`
                            UPDATE posts
                            SET status = 'failed', error_message = ?
                            WHERE id = ?
                        `, [postResult.error, postId], (err) => {
                            if (err) reject(err);
                            else resolve();
                        });
                    });

                    results.push({
                        groupId: group.group_id,
                        groupName: group.name,
                        success: false,
                        error: postResult.error
                    });
                }

                // Add delay between posts to seem human-like
                if (groups.indexOf(group) < groups.length - 1) {
                    await automation.humanDelay(3000, 6000);
                }

            } catch (error) {
                console.error(`Error posting to group ${group.group_id}:`, error);
                
                results.push({
                    groupId: group.group_id,
                    groupName: group.name,
                    success: false,
                    error: error.message
                });
            }
        }

        const successCount = results.filter(r => r.success).length;
        const failureCount = results.filter(r => !r.success).length;

        res.json({
            success: true,
            message: `Posted to ${successCount} groups successfully, ${failureCount} failed`,
            results: results,
            summary: {
                total: results.length,
                successful: successCount,
                failed: failureCount
            }
        });

    } catch (error) {
        console.error('Bulk posting error:', error);
        res.status(500).json({
            error: 'Failed to post to groups',
            message: error.message
        });
    }
});

// Get posting history
router.get('/history', async (req, res) => {
    try {
        const { accountId, status, limit = 50, offset = 0 } = req.query;
        const db = getDatabase();

        let query = `
            SELECT
                p.*,
                fa.name as account_name,
                fg.name as group_name
            FROM posts p
            JOIN facebook_accounts fa ON p.account_id = fa.id
            LEFT JOIN facebook_groups fg ON p.group_id = fg.group_id AND p.account_id = fg.account_id
            WHERE 1=1
        `;
        const params = [];

        if (accountId) {
            query += ' AND p.account_id = ?';
            params.push(accountId);
        }

        if (status) {
            query += ' AND p.status = ?';
            params.push(status);
        }

        query += ' ORDER BY p.created_at DESC LIMIT ? OFFSET ?';
        params.push(parseInt(limit), parseInt(offset));

        const posts = await new Promise((resolve, reject) => {
            db.all(query, params, (err, rows) => {
                if (err) reject(err);
                else resolve(rows);
            });
        });

        res.json({
            success: true,
            posts: posts
        });

    } catch (error) {
        console.error('Get history error:', error);
        res.status(500).json({
            error: 'Failed to get history',
            message: error.message
        });
    }
});

// Get posting statistics
router.get('/stats', async (req, res) => {
    try {
        const { accountId } = req.query;
        const db = getDatabase();

        let query = `
            SELECT
                COUNT(*) as total_posts,
                COUNT(CASE WHEN status = 'posted' THEN 1 END) as successful_posts,
                COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed_posts,
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_posts,
                COUNT(DISTINCT group_id) as unique_groups,
                COUNT(DISTINCT account_id) as unique_accounts
            FROM posts
        `;
        const params = [];

        if (accountId) {
            query += ' WHERE account_id = ?';
            params.push(accountId);
        }

        const stats = await new Promise((resolve, reject) => {
            db.get(query, params, (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });

        res.json({
            success: true,
            stats: {
                totalPosts: stats.total_posts || 0,
                successfulPosts: stats.successful_posts || 0,
                failedPosts: stats.failed_posts || 0,
                pendingPosts: stats.pending_posts || 0,
                uniqueGroups: stats.unique_groups || 0,
                uniqueAccounts: stats.unique_accounts || 0,
                successRate: stats.total_posts > 0 ?
                    ((stats.successful_posts / stats.total_posts) * 100).toFixed(2) : 0
            }
        });

    } catch (error) {
        console.error('Get stats error:', error);
        res.status(500).json({
            error: 'Failed to get stats',
            message: error.message
        });
    }
});

module.exports = router;
