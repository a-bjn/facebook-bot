const express = require('express');
const axios = require('axios');
const { getDatabase } = require('../database/init');
const { generateToken } = require('../middleware/auth');
const FacebookService = require('../services/facebook');
const { facebookApiLimiter } = require('../middleware/rateLimiter');

const router = express.Router();

// Facebook OAuth login URL
router.get('/facebook/login', (req, res) => {
  const facebookAuthUrl = `https://www.facebook.com/v18.0/dialog/oauth?` +
    `client_id=${process.env.FACEBOOK_APP_ID}&` +
    `redirect_uri=${encodeURIComponent(process.env.FACEBOOK_REDIRECT_URI)}&` +
    `scope=email,public_profile,groups_access_member_info,publish_to_groups&` +
    `response_type=code&` +
    `state=${Date.now()}`;

  res.json({ authUrl: facebookAuthUrl });
});

// Facebook OAuth callback
router.post('/facebook/callback', facebookApiLimiter, async (req, res) => {
  try {
    const { code } = req.body;

    if (!code) {
      return res.status(400).json({ error: 'Authorization code is required' });
    }

    // Exchange code for access token
    const tokenResponse = await axios.get('https://graph.facebook.com/v18.0/oauth/access_token', {
      params: {
        client_id: process.env.FACEBOOK_APP_ID,
        client_secret: process.env.FACEBOOK_APP_SECRET,
        redirect_uri: process.env.FACEBOOK_REDIRECT_URI,
        code: code
      }
    });

    const { access_token } = tokenResponse.data;

    // Get long-lived token
    const longLivedTokenData = await FacebookService.getLongLivedToken(access_token);
    const longLivedToken = longLivedTokenData.access_token;
    const expiresIn = longLivedTokenData.expires_in;

    // Get user profile
    const facebookService = new FacebookService(longLivedToken);
    const userProfile = await facebookService.getUserProfile();

    // Save or update account in database
    const db = getDatabase();
    const expiresAt = expiresIn ? Date.now() + (expiresIn * 1000) : null;

    await new Promise((resolve, reject) => {
      db.run(`
        INSERT OR REPLACE INTO facebook_accounts 
        (user_id, access_token, name, email, profile_picture, token_expires_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
      `, [
        userProfile.id,
        longLivedToken,
        userProfile.name,
        userProfile.email || null,
        userProfile.picture?.data?.url || null,
        expiresAt
      ], function(err) {
        if (err) reject(err);
        else resolve(this.lastID);
      });
    });

    // Generate JWT token for session
    const sessionToken = generateToken({
      facebookUserId: userProfile.id,
      name: userProfile.name
    });

    res.json({
      success: true,
      message: 'Facebook account connected successfully',
      user: {
        id: userProfile.id,
        name: userProfile.name,
        email: userProfile.email,
        picture: userProfile.picture?.data?.url
      },
      token: sessionToken
    });

  } catch (error) {
    console.error('Facebook auth error:', error);
    res.status(500).json({
      error: 'Authentication failed',
      message: error.message
    });
  }
});

// Refresh Facebook token
router.post('/facebook/refresh/:accountId', facebookApiLimiter, async (req, res) => {
  try {
    const { accountId } = req.params;
    const db = getDatabase();

    // Get current account
    const account = await new Promise((resolve, reject) => {
      db.get('SELECT * FROM facebook_accounts WHERE id = ?', [accountId], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!account) {
      return res.status(404).json({ error: 'Account not found' });
    }

    // Try to get a new long-lived token
    const newTokenData = await FacebookService.getLongLivedToken(account.access_token);
    const newToken = newTokenData.access_token;
    const expiresIn = newTokenData.expires_in;
    const expiresAt = expiresIn ? Date.now() + (expiresIn * 1000) : null;

    // Update token in database
    await new Promise((resolve, reject) => {
      db.run(`
        UPDATE facebook_accounts 
        SET access_token = ?, token_expires_at = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `, [newToken, expiresAt, accountId], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    res.json({
      success: true,
      message: 'Token refreshed successfully',
      expiresAt: expiresAt
    });

  } catch (error) {
    console.error('Token refresh error:', error);
    res.status(500).json({
      error: 'Failed to refresh token',
      message: error.message
    });
  }
});

// Validate Facebook token
router.get('/facebook/validate/:accountId', facebookApiLimiter, async (req, res) => {
  try {
    const { accountId } = req.params;
    const db = getDatabase();

    const account = await new Promise((resolve, reject) => {
      db.get('SELECT * FROM facebook_accounts WHERE id = ?', [accountId], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!account) {
      return res.status(404).json({ error: 'Account not found' });
    }

    const facebookService = new FacebookService(account.access_token);
    const validation = await facebookService.validateToken();

    res.json({
      valid: validation.valid,
      account: {
        id: account.id,
        name: account.name,
        email: account.email,
        userId: account.user_id
      },
      error: validation.error
    });

  } catch (error) {
    console.error('Token validation error:', error);
    res.status(500).json({
      error: 'Validation failed',
      message: error.message
    });
  }
});

module.exports = router;
