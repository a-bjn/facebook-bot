const express = require('express');
const { getDatabase } = require('../database/init');
const { validateFacebookAccount } = require('../middleware/auth');
const FacebookService = require('../services/facebook');
const { facebookApiLimiter } = require('../middleware/rateLimiter');

const router = express.Router();

// Get all groups for a specific account
router.get('/account/:accountId', validateFacebookAccount, async (req, res) => {
  try {
    const { accountId } = req.params;
    const { canPost, search, limit = 1000, offset = 0 } = req.query; // Increased limit to 1000
    const db = getDatabase();

    let query = `
      SELECT fg.*, fa.name as account_name
      FROM facebook_groups fg
      JOIN facebook_accounts fa ON fg.account_id = fa.id
      WHERE fg.account_id = ?
    `;
    const params = [accountId];

    // Filter by posting capability
    if (canPost !== undefined) {
      query += ' AND fg.can_post = ?';
      params.push(canPost === 'true' ? 1 : 0);
    }

    // Search filter
    if (search) {
      query += ' AND (fg.name LIKE ? OR fg.description LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    query += ' ORDER BY fg.name ASC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const groups = await new Promise((resolve, reject) => {
      db.all(query, params, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    // Get total count for pagination
    let countQuery = 'SELECT COUNT(*) as total FROM facebook_groups WHERE account_id = ?';
    const countParams = [accountId];

    if (canPost !== undefined) {
      countQuery += ' AND can_post = ?';
      countParams.push(canPost === 'true' ? 1 : 0);
    }

    if (search) {
      countQuery += ' AND (name LIKE ? OR description LIKE ?)';
      countParams.push(`%${search}%`, `%${search}%`);
    }

    const totalCount = await new Promise((resolve, reject) => {
      db.get(countQuery, countParams, (err, row) => {
        if (err) reject(err);
        else resolve(row.total);
      });
    });

    res.json({
      success: true,
      groups: groups,
      pagination: {
        total: totalCount,
        limit: parseInt(limit),
        offset: parseInt(offset),
        hasMore: parseInt(offset) + groups.length < totalCount
      }
    });

  } catch (error) {
    console.error('Error fetching groups:', error);
    res.status(500).json({
      error: 'Failed to fetch groups',
      message: error.message
    });
  }
});

// Get specific group details
router.get('/:groupId/account/:accountId', validateFacebookAccount, async (req, res) => {
  try {
    const { groupId, accountId } = req.params;
    const db = getDatabase();

    const group = await new Promise((resolve, reject) => {
      db.get(`
        SELECT fg.*, fa.name as account_name
        FROM facebook_groups fg
        JOIN facebook_accounts fa ON fg.account_id = fa.id
        WHERE fg.group_id = ? AND fg.account_id = ?
      `, [groupId, accountId], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!group) {
      return res.status(404).json({ error: 'Group not found' });
    }

    res.json({
      success: true,
      group: group
    });

  } catch (error) {
    console.error('Error fetching group:', error);
    res.status(500).json({
      error: 'Failed to fetch group',
      message: error.message
    });
  }
});

// Update group posting permission (refresh from Facebook)
router.post('/:groupId/account/:accountId/refresh', validateFacebookAccount, facebookApiLimiter, async (req, res) => {
  try {
    const { groupId, accountId } = req.params;
    const account = req.facebookAccount;
    const db = getDatabase();

    // Check if group exists in our database
    const existingGroup = await new Promise((resolve, reject) => {
      db.get(
        'SELECT * FROM facebook_groups WHERE group_id = ? AND account_id = ?',
        [groupId, accountId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });

    if (!existingGroup) {
      return res.status(404).json({ error: 'Group not found in database' });
    }

    // Get updated group info from Facebook
    const facebookService = new FacebookService(account.access_token);
    const groupInfo = await facebookService.getGroupInfo(groupId);
    const canPost = await facebookService.canPostToGroup(groupId);

    // Update group in database
    await new Promise((resolve, reject) => {
      db.run(`
        UPDATE facebook_groups 
        SET name = ?, description = ?, privacy = ?, member_count = ?, can_post = ?, updated_at = CURRENT_TIMESTAMP
        WHERE group_id = ? AND account_id = ?
      `, [
        groupInfo.name,
        groupInfo.description || null,
        groupInfo.privacy || 'UNKNOWN',
        groupInfo.member_count || 0,
        canPost ? 1 : 0,
        groupId,
        accountId
      ], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    res.json({
      success: true,
      message: 'Group information updated successfully',
      group: {
        id: groupInfo.id,
        name: groupInfo.name,
        description: groupInfo.description,
        privacy: groupInfo.privacy,
        member_count: groupInfo.member_count,
        can_post: canPost
      }
    });

  } catch (error) {
    console.error('Error refreshing group:', error);
    res.status(500).json({
      error: 'Failed to refresh group information',
      message: error.message
    });
  }
});

// Get groups summary for all accounts
router.get('/summary', async (req, res) => {
  try {
    const db = getDatabase();

    const summary = await new Promise((resolve, reject) => {
      db.all(`
        SELECT 
          fa.id as account_id,
          fa.name as account_name,
          fa.profile_picture,
          COUNT(fg.id) as total_groups,
          COUNT(CASE WHEN fg.can_post = 1 THEN 1 END) as postable_groups,
          COUNT(CASE WHEN fg.privacy = 'PUBLIC' THEN 1 END) as public_groups,
          COUNT(CASE WHEN fg.privacy = 'CLOSED' THEN 1 END) as closed_groups,
          COUNT(CASE WHEN fg.privacy = 'SECRET' THEN 1 END) as secret_groups
        FROM facebook_accounts fa
        LEFT JOIN facebook_groups fg ON fa.id = fg.account_id
        GROUP BY fa.id, fa.name, fa.profile_picture
        ORDER BY fa.name
      `, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({
      success: true,
      summary: summary
    });

  } catch (error) {
    console.error('Error fetching groups summary:', error);
    res.status(500).json({
      error: 'Failed to fetch groups summary',
      message: error.message
    });
  }
});

// Search groups across all accounts
router.get('/search', async (req, res) => {
  try {
    const { q, canPost, privacy, limit = 20 } = req.query;
    const db = getDatabase();

    if (!q || q.trim().length < 2) {
      return res.status(400).json({ error: 'Search query must be at least 2 characters long' });
    }

    let query = `
      SELECT fg.*, fa.name as account_name, fa.profile_picture as account_picture
      FROM facebook_groups fg
      JOIN facebook_accounts fa ON fg.account_id = fa.id
      WHERE (fg.name LIKE ? OR fg.description LIKE ?)
    `;
    const params = [`%${q}%`, `%${q}%`];

    if (canPost !== undefined) {
      query += ' AND fg.can_post = ?';
      params.push(canPost === 'true' ? 1 : 0);
    }

    if (privacy) {
      query += ' AND fg.privacy = ?';
      params.push(privacy.toUpperCase());
    }

    query += ' ORDER BY fg.member_count DESC, fg.name ASC LIMIT ?';
    params.push(parseInt(limit));

    const groups = await new Promise((resolve, reject) => {
      db.all(query, params, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({
      success: true,
      groups: groups,
      query: q
    });

  } catch (error) {
    console.error('Error searching groups:', error);
    res.status(500).json({
      error: 'Failed to search groups',
      message: error.message
    });
  }
});

module.exports = router;
