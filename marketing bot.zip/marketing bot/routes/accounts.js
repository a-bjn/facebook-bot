const express = require('express');
const { getDatabase } = require('../database/init');
const { validateFacebookAccount } = require('../middleware/auth');
const FacebookService = require('../services/facebook');
const { facebookApiLimiter } = require('../middleware/rateLimiter');

const router = express.Router();

// Get all Facebook accounts
router.get('/', async (req, res) => {
  try {
    const db = getDatabase();
    
    const accounts = await new Promise((resolve, reject) => {
      db.all(`
        SELECT 
          fa.id, fa.user_id, fa.name, fa.email, fa.profile_picture, 
          fa.token_expires_at, fa.created_at, fa.updated_at,
          COUNT(fg.id) as group_count
        FROM facebook_accounts fa
        LEFT JOIN facebook_groups fg ON fa.id = fg.account_id
        GROUP BY fa.id
        ORDER BY fa.created_at DESC
      `, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    // Check token expiration status and add group count
    const accountsWithStatus = accounts.map(account => ({
      ...account,
      tokenExpired: account.token_expires_at && Date.now() > account.token_expires_at,
      tokenExpiresIn: account.token_expires_at ? Math.max(0, account.token_expires_at - Date.now()) : null,
      groupCount: account.group_count || 0
    }));

    res.json({
      success: true,
      accounts: accountsWithStatus
    });

  } catch (error) {
    console.error('Error fetching accounts:', error);
    res.status(500).json({
      error: 'Failed to fetch accounts',
      message: error.message
    });
  }
});

// Get specific account details
router.get('/:accountId', validateFacebookAccount, async (req, res) => {
  try {
    const account = req.facebookAccount;
    
    res.json({
      success: true,
      account: {
        id: account.id,
        user_id: account.user_id,
        name: account.name,
        email: account.email,
        profile_picture: account.profile_picture,
        token_expires_at: account.token_expires_at,
        tokenExpired: account.token_expires_at && Date.now() > account.token_expires_at,
        tokenExpiresIn: account.token_expires_at ? Math.max(0, account.token_expires_at - Date.now()) : null,
        created_at: account.created_at,
        updated_at: account.updated_at
      }
    });

  } catch (error) {
    console.error('Error fetching account:', error);
    res.status(500).json({
      error: 'Failed to fetch account',
      message: error.message
    });
  }
});

// Delete Facebook account
router.delete('/:accountId', async (req, res) => {
  try {
    const { accountId } = req.params;
    const db = getDatabase();

    // Check if account exists
    const account = await new Promise((resolve, reject) => {
      db.get('SELECT * FROM facebook_accounts WHERE id = ?', [accountId], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!account) {
      return res.status(404).json({ error: 'Account not found' });
    }

    // Delete account (this will cascade delete related groups and posts)
    await new Promise((resolve, reject) => {
      db.run('DELETE FROM facebook_accounts WHERE id = ?', [accountId], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    res.json({
      success: true,
      message: 'Account deleted successfully'
    });

  } catch (error) {
    console.error('Error deleting account:', error);
    res.status(500).json({
      error: 'Failed to delete account',
      message: error.message
    });
  }
});

// Sync account groups (fetch latest groups from Facebook)
router.post('/:accountId/sync-groups', validateFacebookAccount, facebookApiLimiter, async (req, res) => {
  try {
    const account = req.facebookAccount;
    const db = getDatabase();

    const facebookService = new FacebookService(account.access_token);
    const groups = await facebookService.getUserGroups();

    // Clear existing groups for this account
    await new Promise((resolve, reject) => {
      db.run('DELETE FROM facebook_groups WHERE account_id = ?', [account.id], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    // Insert new groups
    const insertPromises = groups.map(group => {
      return new Promise((resolve, reject) => {
        db.run(`
          INSERT INTO facebook_groups 
          (group_id, account_id, name, description, privacy, member_count, can_post)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `, [
          group.id,
          account.id,
          group.name,
          group.description || null,
          group.privacy || 'UNKNOWN',
          group.member_count || 0,
          group.can_post || false
        ], (err) => {
          if (err) reject(err);
          else resolve();
        });
      });
    });

    await Promise.all(insertPromises);

    // Update account sync timestamp
    await new Promise((resolve, reject) => {
      db.run(
        'UPDATE facebook_accounts SET updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [account.id],
        (err) => {
          if (err) reject(err);
          else resolve();
        }
      );
    });

    res.json({
      success: true,
      message: `Synced ${groups.length} groups successfully`,
      groupCount: groups.length
    });

  } catch (error) {
    console.error('Error syncing groups:', error);
    res.status(500).json({
      error: 'Failed to sync groups',
      message: error.message
    });
  }
});

// Get account statistics
router.get('/:accountId/stats', validateFacebookAccount, async (req, res) => {
  try {
    const { accountId } = req.params;
    const db = getDatabase();

    const stats = await new Promise((resolve, reject) => {
      db.get(`
        SELECT 
          COUNT(DISTINCT fg.id) as total_groups,
          COUNT(DISTINCT CASE WHEN fg.can_post = 1 THEN fg.id END) as postable_groups,
          COUNT(DISTINCT p.id) as total_posts,
          COUNT(DISTINCT CASE WHEN p.status = 'posted' THEN p.id END) as successful_posts,
          COUNT(DISTINCT CASE WHEN p.status = 'failed' THEN p.id END) as failed_posts,
          COUNT(DISTINCT CASE WHEN p.status = 'pending' THEN p.id END) as pending_posts
        FROM facebook_accounts fa
        LEFT JOIN facebook_groups fg ON fa.id = fg.account_id
        LEFT JOIN posts p ON fa.id = p.account_id
        WHERE fa.id = ?
      `, [accountId], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    res.json({
      success: true,
      stats: {
        totalGroups: stats.total_groups || 0,
        postableGroups: stats.postable_groups || 0,
        totalPosts: stats.total_posts || 0,
        successfulPosts: stats.successful_posts || 0,
        failedPosts: stats.failed_posts || 0,
        pendingPosts: stats.pending_posts || 0
      }
    });

  } catch (error) {
    console.error('Error fetching account stats:', error);
    res.status(500).json({
      error: 'Failed to fetch account statistics',
      message: error.message
    });
  }
});

module.exports = router;
