const express = require('express');
const { getDatabase } = require('../database/init');
const FacebookAutomation = require('../services/facebook-automation');
const SessionManager = require('../services/session-manager');

const router = express.Router();

// Get or create automation session for syncing (visible browser)
async function getAutomationSession(accountId, visible = true) {
    // Close any existing session and create a new VISIBLE one for syncing
    if (SessionManager.hasSession(accountId)) {
        const oldAutomation = SessionManager.getSession(accountId);
        await oldAutomation.close();
        SessionManager.closeSession(accountId);
    }

    // Create NEW visible browser for syncing
    const automation = new FacebookAutomation();
    await automation.init(false); // VISIBLE browser, not headless
    
    const sessionLoaded = await automation.loadSession(accountId);
    
    if (!sessionLoaded) {
        await automation.close();
        throw new Error('No active session found. Please login to this account first by clicking "Add Account" and entering credentials.');
    }

    // Maximize the window to fullscreen
    const page = automation.page;
    await page.setViewportSize({ width: 1920, height: 1080 });

    // Store in session manager
    SessionManager.setSession(accountId, automation);
    return automation;
}

// Sync groups from Facebook
router.post('/account/:accountId/sync', async (req, res) => {
    try {
        const { accountId } = req.params;
        const db = getDatabase();

        // Get account
        const account = await new Promise((resolve, reject) => {
            db.get('SELECT * FROM facebook_accounts WHERE id = ?', [accountId], (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });

        if (!account) {
            return res.status(404).json({ error: 'Account not found' });
        }

        // Get automation session
        const automation = await getAutomationSession(parseInt(accountId));
        
        // Fetch groups
        const groups = await automation.getGroups();

        if (groups.length === 0) {
            return res.json({
                success: true,
                message: 'No groups found',
                groupCount: 0
            });
        }

        // Clear existing groups
        await new Promise((resolve, reject) => {
            db.run('DELETE FROM facebook_groups WHERE account_id = ?', [accountId], (err) => {
                if (err) reject(err);
                else resolve();
            });
        });

        // Insert groups
        const insertPromises = groups.map(group => {
            return new Promise((resolve, reject) => {
                db.run(`
                    INSERT INTO facebook_groups 
                    (group_id, account_id, name, description, privacy, member_count, can_post)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                `, [
                    group.id,
                    accountId,
                    group.name,
                    group.url,
                    'UNKNOWN',
                    0,
                    true // Assume can post, will verify on actual posting
                ], (err) => {
                    if (err) reject(err);
                    else resolve();
                });
            });
        });

        await Promise.all(insertPromises);

        res.json({
            success: true,
            message: `Synced ${groups.length} groups successfully`,
            groupCount: groups.length
        });

    } catch (error) {
        console.error('Sync groups error:', error);
        res.status(500).json({
            error: 'Failed to sync groups',
            message: error.message
        });
    }
});

// Get groups for account
router.get('/account/:accountId', async (req, res) => {
    try {
        const { accountId } = req.params;
        const { search, limit = 50, offset = 0 } = req.query;
        const db = getDatabase();

        let query = `
            SELECT fg.*, fa.name as account_name
            FROM facebook_groups fg
            JOIN facebook_accounts fa ON fg.account_id = fa.id
            WHERE fg.account_id = ?
        `;
        const params = [accountId];

        if (search) {
            query += ' AND (fg.name LIKE ? OR fg.description LIKE ?)';
            params.push(`%${search}%`, `%${search}%`);
        }

        query += ' ORDER BY fg.name ASC LIMIT ? OFFSET ?';
        params.push(parseInt(limit), parseInt(offset));

        const groups = await new Promise((resolve, reject) => {
            db.all(query, params, (err, rows) => {
                if (err) reject(err);
                else resolve(rows);
            });
        });

        const totalCount = await new Promise((resolve, reject) => {
            let countQuery = 'SELECT COUNT(*) as total FROM facebook_groups WHERE account_id = ?';
            const countParams = [accountId];

            if (search) {
                countQuery += ' AND (name LIKE ? OR description LIKE ?)';
                countParams.push(`%${search}%`, `%${search}%`);
            }

            db.get(countQuery, countParams, (err, row) => {
                if (err) reject(err);
                else resolve(row.total);
            });
        });

        res.json({
            success: true,
            groups: groups,
            pagination: {
                total: totalCount,
                limit: parseInt(limit),
                offset: parseInt(offset),
                hasMore: parseInt(offset) + groups.length < totalCount
            }
        });

    } catch (error) {
        console.error('Get groups error:', error);
        res.status(500).json({
            error: 'Failed to get groups',
            message: error.message
        });
    }
});

module.exports = router;
