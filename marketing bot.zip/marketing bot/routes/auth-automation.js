const express = require('express');
const { getDatabase } = require('../database/init');
const { generateToken } = require('../middleware/auth');
const FacebookAutomation = require('../services/facebook-automation');
const SessionManager = require('../services/session-manager');

const router = express.Router();

// Login with Facebook (browser automation)
router.post('/facebook/login', async (req, res) => {
  try {
    const { email, password, accountName } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const db = getDatabase();
    
    // Create or get account
    const existingAccount = await new Promise((resolve, reject) => {
      db.get('SELECT * FROM facebook_accounts WHERE email = ?', [email], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    let accountId;

    if (existingAccount) {
      accountId = existingAccount.id;
    } else {
      // Create new account
      accountId = await new Promise((resolve, reject) => {
        db.run(`
          INSERT INTO facebook_accounts 
          (user_id, access_token, name, email, created_at, updated_at)
          VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        `, [email, 'browser_session', accountName || email, email], function(err) {
          if (err) reject(err);
          else resolve(this.lastID);
        });
      });
    }

    // Initialize browser automation in VISIBLE FULLSCREEN mode
    const automation = new FacebookAutomation();
    await automation.init(false); // VISIBLE browser
    
    // Set to fullscreen
    await automation.page.setViewportSize({ width: 1920, height: 1080 });

    // Store session
    SessionManager.setSession(accountId, automation);

    // Perform login (fills fields automatically and clicks login)
    const loginResult = await automation.login(email, password, accountId);

    if (loginResult.needsVerification) {
      // Keep browser open for manual verification
      return res.json({
        success: false,
        needsVerification: true,
        accountId: accountId,
        message: loginResult.message
      });
    }

    if (!loginResult.success) {
      await automation.close();
      SessionManager.closeSession(accountId);
      return res.status(401).json({
        error: 'Login failed',
        message: loginResult.message
      });
    }

    // Get user info
    const userName = await automation.page.locator('[aria-label="Account"]').textContent().catch(() => accountName || email);
    
    // Navigate to profile page to get profile picture
    console.log('Fetching profile picture...');
    let profilePictureUrl = null;
    
    try {
      // Go to the user's profile page
      await automation.page.goto('https://www.facebook.com/me', { 
        waitUntil: 'domcontentloaded', // Wait for DOM to be fully loaded
        timeout: 10000 
      });
      await automation.page.waitForTimeout(2000); // Wait for profile picture to load
      
      // Extract profile picture URL with comprehensive selectors
      profilePictureUrl = await automation.page.evaluate(() => {
        // Try multiple selectors for profile picture in order of reliability
        const selectors = [
          'svg image[x="0"]', // SVG profile picture
          'image[x="0"]',
          'img[data-imgperflogname="profileCoverPhoto"]',
          'a[aria-label*="profile picture"] img',
          'a[aria-label*="Change profile picture"] img',
          'div[role="img"] image',
          'img[referrerpolicy="origin-when-cross-origin"]',
          'img[data-visualcompletion="media-vc-image"]',
          // Fallback: any large image near the top
          'img[width="168"]',
          'img[height="168"]'
        ];
        
        for (const selector of selectors) {
          const element = document.querySelector(selector);
          if (element) {
            // For SVG images, get xlink:href
            if (element.tagName.toLowerCase() === 'image') {
              const href = element.getAttribute('xlink:href') || element.getAttribute('href');
              if (href && href.startsWith('http')) {
                console.log('Found profile picture (SVG):', href);
                return href;
              }
            }
            // For img tags, get src
            if (element.src && element.src.startsWith('http')) {
              console.log('Found profile picture (IMG):', element.src);
              return element.src;
            }
          }
        }
        
        console.log('No profile picture found with any selector');
        return null;
      });
      
      console.log('Profile picture URL:', profilePictureUrl);
    } catch (error) {
      console.log('Could not fetch profile picture:', error.message);
    }

    console.log('User info:', { userName, profilePictureUrl });

    // Update account info with profile picture
    await new Promise((resolve, reject) => {
      db.run(`
        UPDATE facebook_accounts 
        SET name = ?, profile_picture = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `, [userName, profilePictureUrl, accountId], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });

    // Use the improved getGroups() method with smart scrolling and connection checks
    console.log('Fetching groups with smart scrolling...');
    const groups = await automation.getGroups();
    
    // Save groups to database
    if (groups.length > 0) {
        // Clear existing groups
        await new Promise((resolve, reject) => {
            db.run('DELETE FROM facebook_groups WHERE account_id = ?', [accountId], (err) => {
                if (err) reject(err);
                else resolve();
            });
        });

        // Insert new groups with better error handling
        let successCount = 0;
        let errorCount = 0;
        
        const insertPromises = groups.map(group => {
            return new Promise((resolve) => {
                db.run(`
                    INSERT OR REPLACE INTO facebook_groups 
                    (group_id, account_id, name, description)
                    VALUES (?, ?, ?, ?)
                `, [
                    group.id,
                    accountId,
                    group.name,
                    group.url
                ], (err) => {
                    if (err) {
                        console.error(`Error inserting group ${group.name}:`, err.message);
                        errorCount++;
                    } else {
                        successCount++;
                    }
                    resolve(); // Always resolve to continue
                });
            });
        });

        await Promise.all(insertPromises);
        console.log(`✅ Saved ${successCount} groups to database`);
        if (errorCount > 0) {
            console.log(`⚠️ Failed to save ${errorCount} groups`);
        }
    }

    // Keep browser open - don't close it
    console.log('✓ Groups synced! Browser window will stay open.');
    // Store automation instance in SessionManager so it can be reused
    SessionManager.setSession(accountId, automation);

    // Generate session token
    const sessionToken = generateToken({
      accountId: accountId,
      email: email,
      name: userName
    });

    res.json({
      success: true,
      message: `Login successful! Synced ${groups.length} groups`,
      accountId: accountId,
      groupCount: groups.length,
      user: {
        id: accountId,
        name: userName,
        email: email
      },
      token: sessionToken
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      error: 'Login failed',
      message: error.message
    });
  }
});

// Confirm manual verification completed
router.post('/facebook/verify-complete/:accountId', async (req, res) => {
  try {
    const { accountId } = req.params;
    const automation = SessionManager.getSession(parseInt(accountId));

    if (!automation) {
      return res.status(404).json({ error: 'Session not found' });
    }

    // Check if verification was completed
    const isLoggedIn = await automation.page.locator('[aria-label="Account"]').count() > 0;

    if (isLoggedIn) {
      await automation.saveSession(accountId);
      
      res.json({
        success: true,
        message: 'Verification completed successfully'
      });
    } else {
      res.status(400).json({
        error: 'Verification not completed',
        message: 'Please complete the verification in the browser'
      });
    }

  } catch (error) {
    console.error('Verification check error:', error);
    res.status(500).json({
      error: 'Verification check failed',
      message: error.message
    });
  }
});

// Close browser session
router.post('/facebook/close-session/:accountId', async (req, res) => {
  try {
    const { accountId } = req.params;
    await SessionManager.closeSession(parseInt(accountId));

    res.json({ success: true, message: 'Session closed' });

  } catch (error) {
    console.error('Close session error:', error);
    res.status(500).json({
      error: 'Failed to close session',
      message: error.message
    });
  }
});

// Check if account has active session
router.get('/facebook/session-status/:accountId', async (req, res) => {
  try {
    const { accountId } = req.params;
    const hasActiveSession = SessionManager.hasSession(parseInt(accountId));

    res.json({
      hasActiveSession: hasActiveSession
    });

  } catch (error) {
    res.status(500).json({
      error: 'Failed to check session status',
      message: error.message
    });
  }
});

module.exports = router;
