const express = require('express');
const { getDatabase } = require('../database/init');
const { validateFacebookAccount } = require('../middleware/auth');
const FacebookService = require('../services/facebook');
const { postingLimiter, facebookApiLimiter } = require('../middleware/rateLimiter');

const router = express.Router();

// Post to multiple groups
router.post('/bulk', postingLimiter, async (req, res) => {
  try {
    const { accountId, groupIds, postUrl, message = '', templateId } = req.body;

    if (!accountId || !groupIds || !Array.isArray(groupIds) || groupIds.length === 0) {
      return res.status(400).json({ 
        error: 'Account ID and group IDs array are required' 
      });
    }

    if (!postUrl || !postUrl.trim()) {
      return res.status(400).json({ 
        error: 'Post URL is required' 
      });
    }

    const db = getDatabase();

    // Get account details
    const account = await new Promise((resolve, reject) => {
      db.get('SELECT * FROM facebook_accounts WHERE id = ?', [accountId], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!account) {
      return res.status(404).json({ error: 'Account not found' });
    }

    // Check token expiration
    if (account.token_expires_at && Date.now() > account.token_expires_at) {
      return res.status(401).json({ 
        error: 'Facebook token expired',
        message: 'Please re-authenticate your Facebook account'
      });
    }

    // Get template if specified
    let finalMessage = message;
    if (templateId) {
      const template = await new Promise((resolve, reject) => {
        db.get('SELECT * FROM post_templates WHERE id = ?', [templateId], (err, row) => {
          if (err) reject(err);
          else resolve(row);
        });
      });

      if (template) {
        finalMessage = template.content.replace(template.url_placeholder || '{URL}', postUrl);
      }
    }

    // Verify groups belong to account and can be posted to
    const validGroups = await new Promise((resolve, reject) => {
      const placeholders = groupIds.map(() => '?').join(',');
      db.all(`
        SELECT group_id, name, can_post 
        FROM facebook_groups 
        WHERE account_id = ? AND group_id IN (${placeholders})
      `, [accountId, ...groupIds], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    if (validGroups.length === 0) {
      return res.status(400).json({ 
        error: 'No valid groups found for this account' 
      });
    }

    const facebookService = new FacebookService(account.access_token);
    const results = [];

    // Post to each group
    for (const group of validGroups) {
      try {
        // Create post record first
        const postId = await new Promise((resolve, reject) => {
          db.run(`
            INSERT INTO posts (account_id, group_id, post_url, status, created_at)
            VALUES (?, ?, ?, 'pending', CURRENT_TIMESTAMP)
          `, [accountId, group.group_id, postUrl], function(err) {
            if (err) reject(err);
            else resolve(this.lastID);
          });
        });

        if (!group.can_post) {
          // Update post as failed
          await new Promise((resolve, reject) => {
            db.run(`
              UPDATE posts 
              SET status = 'failed', error_message = 'No posting permission for this group'
              WHERE id = ?
            `, [postId], (err) => {
              if (err) reject(err);
              else resolve();
            });
          });

          results.push({
            groupId: group.group_id,
            groupName: group.name,
            success: false,
            error: 'No posting permission for this group'
          });
          continue;
        }

        // Attempt to post
        const postResponse = await facebookService.postLinkToGroup(
          group.group_id, 
          postUrl, 
          finalMessage
        );

        // Update post as successful
        await new Promise((resolve, reject) => {
          db.run(`
            UPDATE posts 
            SET status = 'posted', facebook_post_id = ?, posted_at = CURRENT_TIMESTAMP
            WHERE id = ?
          `, [postResponse.id, postId], (err) => {
            if (err) reject(err);
            else resolve();
          });
        });

        results.push({
          groupId: group.group_id,
          groupName: group.name,
          success: true,
          facebookPostId: postResponse.id
        });

        // Add delay between posts to avoid rate limiting
        if (validGroups.indexOf(group) < validGroups.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 2000));
        }

      } catch (error) {
        console.error(`Error posting to group ${group.group_id}:`, error);

        // Update post as failed
        await new Promise((resolve, reject) => {
          db.run(`
            UPDATE posts 
            SET status = 'failed', error_message = ?
            WHERE id = ?
          `, [error.message, postId], (err) => {
            if (err) reject(err);
            else resolve();
          });
        });

        results.push({
          groupId: group.group_id,
          groupName: group.name,
          success: false,
          error: error.message
        });
      }
    }

    const successCount = results.filter(r => r.success).length;
    const failureCount = results.filter(r => !r.success).length;

    res.json({
      success: true,
      message: `Posted to ${successCount} groups successfully, ${failureCount} failed`,
      results: results,
      summary: {
        total: results.length,
        successful: successCount,
        failed: failureCount
      }
    });

  } catch (error) {
    console.error('Bulk posting error:', error);
    res.status(500).json({
      error: 'Failed to post to groups',
      message: error.message
    });
  }
});

// Get posting history
router.get('/history', async (req, res) => {
  try {
    const { accountId, status, limit = 50, offset = 0 } = req.query;
    const db = getDatabase();

    let query = `
      SELECT 
        p.*,
        fa.name as account_name,
        fg.name as group_name
      FROM posts p
      JOIN facebook_accounts fa ON p.account_id = fa.id
      LEFT JOIN facebook_groups fg ON p.group_id = fg.group_id AND p.account_id = fg.account_id
      WHERE 1=1
    `;
    const params = [];

    if (accountId) {
      query += ' AND p.account_id = ?';
      params.push(accountId);
    }

    if (status) {
      query += ' AND p.status = ?';
      params.push(status);
    }

    query += ' ORDER BY p.created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const posts = await new Promise((resolve, reject) => {
      db.all(query, params, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    // Get total count
    let countQuery = 'SELECT COUNT(*) as total FROM posts p WHERE 1=1';
    const countParams = [];

    if (accountId) {
      countQuery += ' AND p.account_id = ?';
      countParams.push(accountId);
    }

    if (status) {
      countQuery += ' AND p.status = ?';
      countParams.push(status);
    }

    const totalCount = await new Promise((resolve, reject) => {
      db.get(countQuery, countParams, (err, row) => {
        if (err) reject(err);
        else resolve(row.total);
      });
    });

    res.json({
      success: true,
      posts: posts,
      pagination: {
        total: totalCount,
        limit: parseInt(limit),
        offset: parseInt(offset),
        hasMore: parseInt(offset) + posts.length < totalCount
      }
    });

  } catch (error) {
    console.error('Error fetching post history:', error);
    res.status(500).json({
      error: 'Failed to fetch post history',
      message: error.message
    });
  }
});

// Get post statistics
router.get('/stats', async (req, res) => {
  try {
    const { accountId } = req.query;
    const db = getDatabase();

    let query = `
      SELECT 
        COUNT(*) as total_posts,
        COUNT(CASE WHEN status = 'posted' THEN 1 END) as successful_posts,
        COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed_posts,
        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_posts,
        COUNT(DISTINCT group_id) as unique_groups,
        COUNT(DISTINCT account_id) as unique_accounts
      FROM posts
    `;
    const params = [];

    if (accountId) {
      query += ' WHERE account_id = ?';
      params.push(accountId);
    }

    const stats = await new Promise((resolve, reject) => {
      db.get(query, params, (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    res.json({
      success: true,
      stats: {
        totalPosts: stats.total_posts || 0,
        successfulPosts: stats.successful_posts || 0,
        failedPosts: stats.failed_posts || 0,
        pendingPosts: stats.pending_posts || 0,
        uniqueGroups: stats.unique_groups || 0,
        uniqueAccounts: stats.unique_accounts || 0,
        successRate: stats.total_posts > 0 ? 
          ((stats.successful_posts / stats.total_posts) * 100).toFixed(2) : 0
      }
    });

  } catch (error) {
    console.error('Error fetching post stats:', error);
    res.status(500).json({
      error: 'Failed to fetch post statistics',
      message: error.message
    });
  }
});

// Delete a post from Facebook (if possible)
router.delete('/:postId', facebookApiLimiter, async (req, res) => {
  try {
    const { postId } = req.params;
    const db = getDatabase();

    // Get post details
    const post = await new Promise((resolve, reject) => {
      db.get(`
        SELECT p.*, fa.access_token
        FROM posts p
        JOIN facebook_accounts fa ON p.account_id = fa.id
        WHERE p.id = ?
      `, [postId], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    if (!post.facebook_post_id) {
      return res.status(400).json({ 
        error: 'Cannot delete post - no Facebook post ID available' 
      });
    }

    // Try to delete from Facebook
    const facebookService = new FacebookService(post.access_token);
    
    try {
      await facebookService.deletePost(post.facebook_post_id);
      
      // Update post status in database
      await new Promise((resolve, reject) => {
        db.run(`
          UPDATE posts 
          SET status = 'deleted', updated_at = CURRENT_TIMESTAMP
          WHERE id = ?
        `, [postId], (err) => {
          if (err) reject(err);
          else resolve();
        });
      });

      res.json({
        success: true,
        message: 'Post deleted successfully from Facebook'
      });

    } catch (fbError) {
      res.status(400).json({
        error: 'Failed to delete post from Facebook',
        message: fbError.message,
        suggestion: 'The post may have already been deleted or you may not have permission to delete it'
      });
    }

  } catch (error) {
    console.error('Error deleting post:', error);
    res.status(500).json({
      error: 'Failed to delete post',
      message: error.message
    });
  }
});

module.exports = router;
