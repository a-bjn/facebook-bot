const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const DB_PATH = process.env.DB_PATH || './database.sqlite';

let db;

function initializeDatabase() {
  return new Promise((resolve, reject) => {
    db = new sqlite3.Database(DB_PATH, (err) => {
      if (err) {
        console.error('Error opening database:', err);
        reject(err);
        return;
      }
      
      console.log('Connected to SQLite database');
      
      // Create tables
      const createTables = `
        -- Facebook Accounts table
        CREATE TABLE IF NOT EXISTS facebook_accounts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id TEXT UNIQUE NOT NULL,
          access_token TEXT NOT NULL,
          refresh_token TEXT,
          name TEXT NOT NULL,
          email TEXT,
          profile_picture TEXT,
          token_expires_at INTEGER,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        -- Facebook Groups table (simplified - only essential fields)
        CREATE TABLE IF NOT EXISTS facebook_groups (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          group_id TEXT NOT NULL,
          account_id INTEGER NOT NULL,
          name TEXT NOT NULL,
          description TEXT,
          FOREIGN KEY (account_id) REFERENCES facebook_accounts (id) ON DELETE CASCADE,
          UNIQUE(group_id, account_id)
        );

        -- Posts table to track what has been posted
        CREATE TABLE IF NOT EXISTS posts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          account_id INTEGER NOT NULL,
          group_id TEXT NOT NULL,
          post_url TEXT NOT NULL,
          facebook_post_id TEXT,
          status TEXT DEFAULT 'pending', -- pending, posted, failed
          error_message TEXT,
          scheduled_at DATETIME,
          posted_at DATETIME,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (account_id) REFERENCES facebook_accounts (id) ON DELETE CASCADE
        );

        -- Post templates for reusable content
        CREATE TABLE IF NOT EXISTS post_templates (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          content TEXT NOT NULL,
          url_placeholder TEXT DEFAULT '{URL}',
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        -- Posting schedules
        CREATE TABLE IF NOT EXISTS posting_schedules (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          account_id INTEGER NOT NULL,
          group_ids TEXT NOT NULL, -- JSON array of group IDs
          post_url TEXT NOT NULL,
          template_id INTEGER,
          schedule_type TEXT DEFAULT 'immediate', -- immediate, scheduled, recurring
          scheduled_time DATETIME,
          recurring_pattern TEXT, -- JSON for recurring schedules
          status TEXT DEFAULT 'active', -- active, paused, completed
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (account_id) REFERENCES facebook_accounts (id) ON DELETE CASCADE,
          FOREIGN KEY (template_id) REFERENCES post_templates (id) ON DELETE SET NULL
        );

        -- Create indexes for better performance
        CREATE INDEX IF NOT EXISTS idx_facebook_accounts_user_id ON facebook_accounts(user_id);
        CREATE INDEX IF NOT EXISTS idx_facebook_groups_account_id ON facebook_groups(account_id);
        CREATE INDEX IF NOT EXISTS idx_facebook_groups_group_id ON facebook_groups(group_id);
        CREATE INDEX IF NOT EXISTS idx_posts_account_id ON posts(account_id);
        CREATE INDEX IF NOT EXISTS idx_posts_status ON posts(status);
        CREATE INDEX IF NOT EXISTS idx_posting_schedules_account_id ON posting_schedules(account_id);
        CREATE INDEX IF NOT EXISTS idx_posting_schedules_status ON posting_schedules(status);
      `;

      db.exec(createTables, (err) => {
        if (err) {
          console.error('Error creating tables:', err);
          reject(err);
          return;
        }
        
        console.log('Database tables created successfully');
        resolve();
      });
    });
  });
}

function getDatabase() {
  if (!db) {
    throw new Error('Database not initialized. Call initializeDatabase() first.');
  }
  return db;
}

function closeDatabase() {
  return new Promise((resolve, reject) => {
    if (db) {
      db.close((err) => {
        if (err) {
          reject(err);
          return;
        }
        console.log('Database connection closed');
        resolve();
      });
    } else {
      resolve();
    }
  });
}

module.exports = {
  initializeDatabase,
  getDatabase,
  closeDatabase
};
